"""Trading engine: EMA trend-following with ATR stops, strict risk limits.

Strategy (conservative, fee-aware — designed for small accounts):
  * 1-hour candles. Buy when the fast EMA crosses above the slow EMA,
    and (regime filter) only while price is above the 200-period EMA —
    trend systems bleed money in choppy markets; this skips most chop.
  * Initial stop-loss = entry − stop_atr × ATR; stop trails up as price rises.
  * Exit on stop hit or when the trend reverses (fast EMA crosses back below).
  * Position size: risk_per_trade of equity divided by the stop distance,
    capped at max_pos_frac of equity.
  * If equity falls daily_halt below the day's starting equity, everything is
    sold and trading halts until the next day.
  * Fees: entries and unhurried exits use maker (limit) orders when
    prefer_maker is on — roughly half the fee of market orders. Stop-outs are
    always market orders: protection beats fee savings.
  * Live mode also parks a stop-limit sell on Coinbase itself, so positions
    stay protected even if this PC is off.

Runs in a background thread; talks to the GUI through an event queue and
receives commands (start/pause/flatten/reload) through a command queue.
"""

import datetime
import queue
import threading
import time
import traceback

from . import market
from . import notify
from . import secure


def ema_series(values, period):
    if len(values) < period:
        return None
    k = 2.0 / (period + 1)
    e = sum(values[:period]) / period
    out = [e]
    for v in values[period:]:
        e = v * k + e * (1 - k)
        out.append(e)
    return out


def atr_value(candles, period=14):
    if len(candles) < period + 1:
        return None
    trs = []
    prev_close = candles[0][4]
    for t, lo, hi, op, cl, vol in candles[1:]:
        trs.append(max(hi - lo, abs(hi - prev_close), abs(lo - prev_close)))
        prev_close = cl
    a = sum(trs[:period]) / period
    for tr in trs[period:]:
        a = (a * (period - 1) + tr) / period
    return a


class Engine(threading.Thread):
    def __init__(self, store, events):
        super().__init__(daemon=True)
        self.store = store
        self.events = events          # engine -> GUI
        self.commands = queue.Queue() # GUI -> engine
        self._stop = threading.Event()

        self.cfg = store.load_settings()
        state = store.load_paper_state()
        if state is None:
            state = {"cash": self.cfg["paper_start_cash"], "positions": {},
                     "baseline": self.cfg["paper_start_cash"]}
            store.save_paper_state(state)
        self.cash = state["cash"]
        self.positions = state["positions"]  # pair -> dict
        self.baseline = state.get("baseline", self.cfg["paper_start_cash"])
        self.baseline_btc = state.get("baseline_btc")   # BTC price at account start
        self.baseline_ts = state.get("baseline_ts")

        self.running = False
        self.halted = False
        self.conn_ok = None
        self.prices = {}
        self.day = None
        self.day_start_equity = None
        self._last_signal = {}
        self._last_err_notify = 0.0
        self.broker = None
        self.last_error = ""

        # tick health tracking (success visibility without flooding the log)
        self._tick_fail_streak = 0
        self._tick_hour_ok = 0
        self._tick_hour_fail = 0
        self._tick_report_at = time.time() + 3600
        self._last_tick_ok = None

    # ---------- helpers ----------
    def log(self, level, msg):
        self.store.log(level, msg)
        self.events.put({"type": "log", "ts": time.time(), "level": level, "msg": msg})

    def _notify(self, title, msg):
        notify.send_async(self.cfg, title, msg)

    def _note_tick_success(self):
        """Validate a completed tick and surface success in the activity log.

        Logged lines (level "ok") are kept rare on purpose: a recovery line
        after failures, and an hourly health summary — so trades and errors
        stay visible in the activity feed.
        """
        missing = [p for p in self.cfg["pairs"]
                   if not (isinstance(self.prices.get(p), (int, float))
                           and self.prices[p] > 0)]
        if missing:
            self.log("warn", "Tick completed but no fresh price for: "
                             + ", ".join(missing))
        else:
            self.conn_ok = True
        self._last_tick_ok = time.time()
        self._tick_hour_ok += 1
        if self._tick_fail_streak:
            self.log("ok", f"Tick OK — recovered after {self._tick_fail_streak} "
                           f"failed attempt(s); {len(self.cfg['pairs'])} pairs priced")
            self._tick_fail_streak = 0
        if time.time() >= self._tick_report_at:
            total = self._tick_hour_ok + self._tick_hour_fail
            self.log("ok", f"Tick health: {self._tick_hour_ok}/{total} checks "
                           f"succeeded in the last hour")
            self._tick_hour_ok = self._tick_hour_fail = 0
            self._tick_report_at = time.time() + 3600

    def equity(self):
        eq = self.cash
        for pair, pos in self.positions.items():
            eq += pos["qty"] * self.prices.get(pair, pos["entry"])
        return eq

    def _persist(self):
        self.store.save_paper_state({
            "cash": self.cash, "positions": self.positions,
            "baseline": self.baseline, "baseline_btc": self.baseline_btc,
            "baseline_ts": self.baseline_ts})

    def _emit_status(self):
        self.events.put({
            "type": "status",
            "ts": time.time(),
            "state": ("halted" if self.halted else ("running" if self.running else "paused")),
            "mode": self.cfg["mode"],
            "conn": self.conn_ok,
            "prices": dict(self.prices),
            "equity": self.equity(),
            "cash": self.cash,
            "day_start": self.day_start_equity,
            "baseline": self.baseline,
            "baseline_btc": self.baseline_btc,
            "baseline_ts": self.baseline_ts,
            "positions": {p: dict(v) for p, v in self.positions.items()},
            "last_error": self.last_error,
            "last_tick_ok": self._last_tick_ok,
        })

    def _make_broker(self):
        key = self.store.get("cb_key_name")
        sec = self.store.get("cb_private_key")
        if not key or not sec:
            raise RuntimeError("No API keys saved. Add them in the API Keys tab.")
        return market.LiveBroker(secure.unprotect(key), secure.unprotect(sec))

    # ---------- live-order helpers ----------
    def _live_enter(self, pair, qty, price, cost):
        """Buy on Coinbase, preferring a post-only limit (maker fee).
        Returns (fill_price, fee_rate_used, note)."""
        cfg = self.cfg
        if cfg["prefer_maker"]:
            try:
                oid = self.broker.limit_buy_post_only(pair, qty, round(price, 2))
                deadline = time.time() + cfg["maker_wait_seconds"]
                while time.time() < deadline and not self._stop.is_set():
                    time.sleep(5)
                    filled, avg = self.broker.order_filled(oid, pair)
                    if filled:
                        return (avg or price), cfg["maker_fee"], f"limit order {oid}"
                self.broker.cancel_safe(oid, pair)
                filled, avg = self.broker.order_filled(oid, pair)
                if filled:  # filled in the race with our cancel
                    return (avg or price), cfg["maker_fee"], f"limit order {oid}"
                self.log("info", f"{pair} limit order didn't fill in "
                                 f"{cfg['maker_wait_seconds']}s — using market order")
            except Exception as e:
                self.log("warn", f"{pair} limit order failed ({e}) — using market order")
        oid = self.broker.market_buy_cost(pair, round(cost, 2))
        return price, cfg["fee_rate"], f"market order {oid}"

    def _place_live_stop(self, pair, pos):
        try:
            pos["stop_oid"] = self.broker.place_stop_sell(
                pair, pos["qty"], round(pos["stop"], 2))
            self.log("info", f"{pair}: stop-loss order parked on Coinbase at "
                             f"${pos['stop']:,.2f} (protects you even if this PC is off)")
        except Exception as e:
            pos["stop_oid"] = None
            self.log("warn", f"{pair}: couldn't place exchange stop ({e}) — "
                             f"falling back to app-managed stop")

    def _move_live_stop(self, pair, pos):
        if pos.get("stop_oid"):
            self.broker.cancel_safe(pos["stop_oid"], pair)
        self._place_live_stop(pair, pos)

    def _check_live_stop_filled(self, pair, pos):
        """If the exchange-side stop already executed, book the exit."""
        if not pos.get("stop_oid"):
            return False
        try:
            filled, avg = self.broker.order_filled(pos["stop_oid"], pair)
        except Exception:
            return False
        if not filled:
            return False
        fill = avg or pos["stop"]
        self.positions.pop(pair, None)
        proceeds = pos["qty"] * fill
        fee = proceeds * self.cfg["fee_rate"]
        self.cash += proceeds - fee
        pnl = proceeds - fee - pos["cost"]
        self.store.close_trade(pos["trade_id"], fill, fee, pnl,
                               "Exchange stop-loss executed")
        self._persist()
        sign = "+" if pnl >= 0 else "−"
        msg = (f"SELL {pos['qty']:.6f} {pair} @ ${fill:,.2f} — exchange "
               f"stop-loss executed; P&L {sign}${abs(pnl):,.2f}")
        self.log("trade", msg)
        self._notify(f"Sold {pair}", msg)
        return True

    # ---------- trading ----------
    def _buy(self, pair, price, atr):
        cfg = self.cfg
        entry_fee_rate = cfg["maker_fee"] if cfg["prefer_maker"] else cfg["fee_rate"]
        eq = self.equity()
        risk_amt = eq * cfg["risk_per_trade"]
        stop_dist = cfg["stop_atr"] * atr
        if stop_dist <= 0:
            return
        qty = risk_amt / stop_dist
        notional = qty * price
        cap = min(cfg["max_pos_frac"] * eq,
                  self.cash / (1 + entry_fee_rate) * 0.995)
        if notional > cap:
            notional = cap
            qty = notional / price
        if notional < cfg["min_notional"]:
            self.log("info", f"Skipped {pair} buy signal — position would be "
                             f"${notional:,.2f}, below ${cfg['min_notional']:,.0f} minimum")
            return

        if cfg["mode"] == "live":
            fill, fee_rate, note = self._live_enter(pair, qty, price, notional)
            note = f" ({note})"
        else:
            fill = price * (1 + cfg["slippage"])
            fee_rate = entry_fee_rate
            note = ""
        cost = qty * fill
        fee = cost * fee_rate
        self.cash -= cost + fee
        stop = fill - cfg["stop_atr"] * atr
        tf = cfg["granularity"]
        tf_txt = f"{tf // 3600}h" if tf >= 3600 else f"{tf // 60}m"
        reason = (f"EMA{cfg['ema_fast']}/{cfg['ema_slow']} cross up on "
                  f"{tf_txt} candles"
                  + (", above EMA200" if cfg.get("trend_filter") else ""))
        trade_id = self.store.open_trade(cfg["mode"], pair, qty, fill, fee, reason)
        self.positions[pair] = {"qty": qty, "entry": fill, "stop": stop,
                                "cost": cost + fee, "trade_id": trade_id,
                                "opened": time.time(), "stop_oid": None}
        if cfg["mode"] == "live":
            self._place_live_stop(pair, self.positions[pair])
        self._persist()
        msg = (f"BUY {qty:.6f} {pair} @ ${fill:,.2f} — {reason}; "
               f"stop ${stop:,.2f} (risking ${risk_amt:,.2f}){note}")
        self.log("trade", msg)
        self._notify(f"Bought {pair}", msg)

    def _sell(self, pair, price, reason, urgent=True):
        """urgent exits (stops, halts, manual) pay taker; calm exits pay maker."""
        cfg = self.cfg
        pos = self.positions.pop(pair, None)
        if not pos:
            return
        fee_rate = cfg["fee_rate"] if (urgent or not cfg["prefer_maker"]) \
            else cfg["maker_fee"]
        fill = price * (1 - cfg["slippage"])
        if cfg["mode"] == "live":
            try:
                if pos.get("stop_oid"):
                    cancelled = self.broker.cancel_safe(pos["stop_oid"], pair)
                    if not cancelled:
                        # the stop may have just executed on the exchange
                        self.positions[pair] = pos
                        if self._check_live_stop_filled(pair, pos):
                            return
                        self.positions.pop(pair, None)
                order_id = self.broker.market_sell(pair, pos["qty"])
                fee_rate = cfg["fee_rate"]  # live exits are market orders
                note = f" (order {order_id})"
            except Exception as e:
                self.positions[pair] = pos  # keep tracking it
                self.log("error", f"LIVE SELL FAILED for {pair}: {e}")
                self._notify("SELL FAILED", f"{pair}: {e}")
                return
        else:
            note = ""
        proceeds = pos["qty"] * fill
        fee = proceeds * fee_rate
        self.cash += proceeds - fee
        pnl = proceeds - fee - pos["cost"]
        self.store.close_trade(pos["trade_id"], fill, fee, pnl, reason)
        self._persist()
        sign = "+" if pnl >= 0 else "−"
        msg = (f"SELL {pos['qty']:.6f} {pair} @ ${fill:,.2f} — {reason}; "
               f"P&L {sign}${abs(pnl):,.2f}{note}")
        self.log("trade", msg)
        self._notify(f"Sold {pair}", msg)

    def _flatten(self, reason):
        for pair in list(self.positions):
            try:
                price = self.prices.get(pair) or market.get_price(pair)
                self._sell(pair, price, reason, urgent=True)
            except Exception as e:
                self.log("error", f"Could not flatten {pair}: {e}")

    def _tick(self):
        cfg = self.cfg
        today = datetime.date.today().isoformat()
        if self.day != today:
            self.day = today
            self.day_start_equity = self.equity()
            if self.halted:
                self.halted = False
                self.log("info", "New day — daily-loss halt lifted, trading resumed")

        for pair in cfg["pairs"]:
            candles = market.get_closed_candles(pair, cfg["granularity"])
            self.conn_ok = True
            if len(candles) < cfg["ema_slow"] + 3:
                self.log("warn", f"Not enough candle data for {pair}; skipping")
                continue
            closes = [c[4] for c in candles]
            ef = ema_series(closes, cfg["ema_fast"])
            es = ema_series(closes, cfg["ema_slow"])
            atr = atr_value(candles, cfg["atr_period"])
            if not ef or not es or not atr:
                continue
            e200 = ema_series(closes, 200) if len(closes) >= 200 else None
            cross_up = ef[-1] > es[-1] and ef[-2] <= es[-2]
            cross_down = ef[-1] < es[-1] and ef[-2] >= es[-2]
            price = market.get_price(pair)
            self.prices[pair] = price

            pos = self.positions.get(pair)
            if pos:
                if cfg["mode"] == "live" and self._check_live_stop_filled(pair, pos):
                    continue
                new_stop = price - cfg["trail_atr"] * atr
                if new_stop > pos["stop"]:
                    moved = (new_stop - pos["stop"]) / price
                    pos["stop"] = new_stop
                    self._persist()
                    # re-park the exchange stop only on meaningful moves (>0.5%)
                    if cfg["mode"] == "live" and moved > 0.005:
                        self._move_live_stop(pair, pos)
                if price <= pos["stop"]:
                    self._sell(pair, price, "Trailing stop hit", urgent=True)
                elif cross_down:
                    self._sell(pair, price, "Trend reversed (EMA cross down)",
                               urgent=False)
            elif cross_up and not self.halted:
                if cfg.get("trend_filter") and e200 and price <= e200[-1]:
                    self.log("info", f"Skipped {pair} buy signal — price below "
                                     f"EMA200 (choppy/down market filter)")
                    continue
                last_candle_ts = candles[-1][0]
                if self._last_signal.get(pair) != last_candle_ts:
                    self._last_signal[pair] = last_candle_ts
                    self._buy(pair, price, atr)

        # benchmark baseline: BTC price when this account started
        if self.baseline_btc is None:
            try:
                btc = self.prices.get("BTC-USD") or market.get_price("BTC-USD")
                self.prices.setdefault("BTC-USD", btc)
                self.baseline_btc = btc
                self.baseline_ts = time.time()
                self._persist()
            except Exception:
                pass
        elif "BTC-USD" not in self.cfg["pairs"]:
            try:
                self.prices["BTC-USD"] = market.get_price("BTC-USD")
            except Exception:
                pass

        # Daily loss circuit breaker
        eq = self.equity()
        if (not self.halted and self.day_start_equity
                and eq <= self.day_start_equity * (1 - cfg["daily_halt"])):
            self.halted = True
            msg = (f"DAILY LOSS LIMIT hit ({cfg['daily_halt']:.0%}) — "
                   f"selling everything and halting until tomorrow")
            self.log("warn", msg)
            self._notify("Trading halted", msg)
            self._flatten("Daily loss limit")
        self.store.snapshot_equity(cfg["mode"], eq)

    # ---------- command handling ----------
    def _handle_command(self, cmd):
        name = cmd[0]
        if name == "start":
            if self.cfg["mode"] == "live" and self.broker is None:
                try:
                    self.broker = self._make_broker()
                    usd = self.broker.usd_balance()
                    self.cash = usd
                    self.log("info", f"LIVE mode connected — ${usd:,.2f} available on Coinbase")
                except Exception as e:
                    self.log("error", f"Cannot start live trading: {e}")
                    return
            self.running = True
            self.store.set("engine_running", "1")  # so a headless Pi auto-resumes
            self.log("info", f"Bot started ({self.cfg['mode']} mode) — watching "
                             + ", ".join(self.cfg["pairs"]))
        elif name == "pause":
            self.running = False
            self.store.set("engine_running", "0")
            self.log("info", "Bot paused — open positions are still tracked, no new trades")
        elif name == "flatten":
            self.log("warn", "EMERGENCY STOP — selling all positions now")
            self._flatten("Manual emergency stop")
            self.running = False
            self.store.set("engine_running", "0")
        elif name == "reload":
            old_mode = self.cfg["mode"]
            self.cfg = self.store.load_settings()
            if self.cfg["mode"] != old_mode:
                self.broker = None
                self.running = False
                if self.cfg["mode"] == "paper":
                    state = self.store.load_paper_state() or {}
                    self.cash = state.get("cash", self.cfg["paper_start_cash"])
                self.log("info", f"Switched to {self.cfg['mode'].upper()} mode "
                                 f"— press Start to begin")
            self.log("info", "Settings reloaded")
        elif name == "reset_paper":
            self.positions.clear()
            self.cash = self.cfg["paper_start_cash"]
            self.baseline = self.cfg["paper_start_cash"]
            self.baseline_btc = None
            self.baseline_ts = None
            self.store.reset_paper(self.cfg["paper_start_cash"])
        elif name == "test_notify":
            self._notify("Crypto Trader", "Test notification — you're connected!")
            self.log("info", "Test notification sent (check your phone)")
        self._emit_status()

    # ---------- main loop ----------
    def run(self):
        self.log("info", "Engine started")
        self._emit_status()
        next_tick = 0
        while not self._stop.is_set():
            try:
                cmd = self.commands.get(timeout=1.0)
            except queue.Empty:
                cmd = None
            if cmd:
                try:
                    self._handle_command(cmd)
                except Exception as e:
                    self.last_error = str(e)
                    self.log("error", f"Command failed: {e}")
                continue
            if time.time() >= next_tick:
                next_tick = time.time() + max(15, int(self.cfg["poll_seconds"]))
                if self.running:
                    try:
                        self._tick()
                        self.last_error = ""
                        self._note_tick_success()
                    except Exception as e:
                        self.conn_ok = False
                        self.last_error = str(e)
                        self._tick_fail_streak += 1
                        self._tick_hour_fail += 1
                        self.log("error", f"Tick failed (will retry): "
                                          f"{e.__class__.__name__}: {e}")
                        if (self.cfg["mode"] == "live"
                                and time.time() - self._last_err_notify > 900):
                            self._last_err_notify = time.time()
                            self._notify("Bot error (live mode)", str(e))
                        traceback.print_exc()
                else:
                    # keep prices fresh even when paused
                    try:
                        for pair in self.cfg["pairs"]:
                            self.prices[pair] = market.get_price(pair)
                        self.conn_ok = True
                    except Exception:
                        self.conn_ok = False
                self._emit_status()

    def shutdown(self):
        self._stop.set()
