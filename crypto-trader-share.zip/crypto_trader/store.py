"""SQLite persistence: action log, trades, equity history, settings, encrypted keys."""

import json
import os
import sqlite3
import threading
import time

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "trader.db")

DEFAULT_SETTINGS = {
    "mode": "paper",                 # "paper" or "live"
    "pairs": ["BTC-USD", "ETH-USD"],
    "granularity": 21600,            # candle size in seconds (6h — backtested best)
    "ema_fast": 20,
    "ema_slow": 50,
    "atr_period": 14,
    "stop_atr": 2.0,                 # initial stop distance in ATRs
    "trail_atr": 3.0,                # trailing stop distance in ATRs
    "risk_per_trade": 0.01,          # fraction of equity risked per trade
    "max_pos_frac": 0.5,             # max fraction of equity in one position
    "daily_halt": 0.05,              # halt trading if equity drops this much in a day
    "fee_rate": 0.008,               # taker fee estimate (adjust to your Coinbase tier)
    "maker_fee": 0.004,              # maker (limit-order) fee estimate
    "prefer_maker": True,            # use limit orders to pay maker fees when possible
    "maker_wait_seconds": 45,        # how long to wait for a limit fill before market fallback
    "trend_filter": True,            # only buy when price is above the 200-period EMA
    "slippage": 0.0005,              # paper-fill slippage estimate
    "poll_seconds": 60,
    "paper_start_cash": 1000.0,
    "min_notional": 10.0,            # skip trades smaller than this (fees would eat them)
    "ntfy_topic": "",                # ntfy.sh topic for phone notifications (optional)
    "telegram_token": "",            # Telegram bot token (optional)
    "telegram_chat": "",             # Telegram chat id (optional)
    "web_port": 8080,                # web dashboard port (headless/Pi mode)
    "web_password": "",              # optional password for the web dashboard
}


class Store:
    def __init__(self, path=DB_PATH):
        self._lock = threading.Lock()
        # Human-readable trade log, kept next to the database file.
        self._history_path = os.path.join(
            os.path.dirname(os.path.abspath(path)), "trading_history.txt")
        self._db = sqlite3.connect(path, check_same_thread=False)
        self._db.execute("PRAGMA journal_mode=WAL")
        self._init_tables()
        try:
            self.sync_history_file()
        except Exception as e:
            self.log("warn", f"trading_history.txt sync failed: {e}")

    def _init_tables(self):
        with self._lock:
            c = self._db
            c.execute("""CREATE TABLE IF NOT EXISTS actions(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts REAL, level TEXT, message TEXT)""")
            c.execute("""CREATE TABLE IF NOT EXISTS trades(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                mode TEXT, pair TEXT, qty REAL,
                entry REAL, exit REAL, fee REAL, pnl REAL,
                opened REAL, closed REAL, status TEXT,
                reason_open TEXT, reason_close TEXT)""")
            c.execute("""CREATE TABLE IF NOT EXISTS equity(
                ts REAL, mode TEXT, value REAL)""")
            c.execute("""CREATE TABLE IF NOT EXISTS kv(
                key TEXT PRIMARY KEY, value TEXT)""")
            c.execute("""CREATE TABLE IF NOT EXISTS candles(
                pair TEXT, gran INTEGER, ts INTEGER,
                low REAL, high REAL, open REAL, close REAL, vol REAL,
                PRIMARY KEY(pair, gran, ts))""")
            c.commit()

    # ---- key/value ----
    def get(self, key, default=None):
        with self._lock:
            row = self._db.execute("SELECT value FROM kv WHERE key=?", (key,)).fetchone()
        return row[0] if row else default

    def set(self, key, value):
        with self._lock:
            self._db.execute(
                "INSERT INTO kv(key,value) VALUES(?,?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))
            self._db.commit()

    def delete(self, key):
        with self._lock:
            self._db.execute("DELETE FROM kv WHERE key=?", (key,))
            self._db.commit()

    # ---- settings ----
    def load_settings(self):
        raw = self.get("settings")
        cfg = dict(DEFAULT_SETTINGS)
        if raw:
            try:
                cfg.update(json.loads(raw))
            except (ValueError, TypeError):
                pass
        return cfg

    def save_settings(self, cfg):
        self.set("settings", json.dumps(cfg))

    # ---- paper account state ----
    def load_paper_state(self):
        raw = self.get("paper_state")
        if raw:
            try:
                return json.loads(raw)
            except (ValueError, TypeError):
                pass
        return None

    def save_paper_state(self, state):
        self.set("paper_state", json.dumps(state))

    # ---- actions ----
    def log(self, level, message, ts=None):
        with self._lock:
            self._db.execute("INSERT INTO actions(ts,level,message) VALUES(?,?,?)",
                             (ts or time.time(), level, message))
            self._db.commit()

    def recent_actions(self, limit=300):
        with self._lock:
            rows = self._db.execute(
                "SELECT ts,level,message FROM actions ORDER BY id DESC LIMIT ?",
                (limit,)).fetchall()
        return rows

    # ---- trades ----
    def open_trade(self, mode, pair, qty, entry, fee, reason):
        with self._lock:
            cur = self._db.execute(
                "INSERT INTO trades(mode,pair,qty,entry,fee,opened,status,reason_open) "
                "VALUES(?,?,?,?,?,?,?,?)",
                (mode, pair, qty, entry, fee, time.time(), "open", reason))
            self._db.commit()
            return cur.lastrowid

    def close_trade(self, trade_id, exit_price, extra_fee, pnl, reason):
        with self._lock:
            self._db.execute(
                "UPDATE trades SET exit=?, fee=fee+?, pnl=?, closed=?, status='closed', "
                "reason_close=? WHERE id=?",
                (exit_price, extra_fee, pnl, time.time(), reason, trade_id))
            self._db.commit()
            row = self._db.execute(
                "SELECT opened,closed,mode,pair,qty,entry,exit,fee,pnl,"
                "reason_open,reason_close FROM trades WHERE id=?",
                (trade_id,)).fetchone()
        if row:
            try:
                self._append_history_line(row)
            except OSError as e:
                self.log("warn", f"could not write trading_history.txt: {e}")

    def recent_trades(self, limit=200):
        with self._lock:
            rows = self._db.execute(
                "SELECT opened,closed,mode,pair,qty,entry,exit,fee,pnl,status,"
                "reason_open,reason_close FROM trades ORDER BY id DESC LIMIT ?",
                (limit,)).fetchall()
        return rows

    # ---- trading_history.txt (human-readable trade log next to trader.db) ----
    #
    # One tab-separated line per CLOSED trade. The file is the durable,
    # shareable record: at startup any trades found here that are missing from
    # the database are imported back, then the file is rewritten canonically.

    _HISTORY_HEADER = (
        "# Crypto Trader — trading history (auto-generated; one closed trade per line)\n"
        "# Columns (tab-separated):\n"
        "# opened_epoch\tclosed_epoch\topened_local\tclosed_local\tmode\tpair\t"
        "qty\tentry\texit\tfee\tpnl\treason_open\treason_close\n")

    @staticmethod
    def _history_fmt(row):
        """row: (opened,closed,mode,pair,qty,entry,exit,fee,pnl,r_open,r_close)"""
        opened, closed, mode, pair, qty, entry, exit_, fee, pnl, ro, rc = row
        local = lambda ts: time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts)) if ts else "-"
        clean = lambda s: (s or "").replace("\t", " ").replace("\n", " ")
        return (f"{opened:.3f}\t{closed:.3f}\t{local(opened)}\t{local(closed)}\t"
                f"{mode}\t{pair}\t{qty:.8f}\t{entry:.8f}\t{exit_:.8f}\t"
                f"{fee:.8f}\t{pnl:.8f}\t{clean(ro)}\t{clean(rc)}\n")

    def _append_history_line(self, row):
        new_file = not os.path.exists(self._history_path)
        with open(self._history_path, "a", encoding="utf-8") as f:
            if new_file:
                f.write(self._HISTORY_HEADER)
            f.write(self._history_fmt(row))

    def _parse_history_file(self):
        """Return list of trade tuples parsed from the txt (skips bad lines)."""
        out = []
        if not os.path.exists(self._history_path):
            return out
        with open(self._history_path, encoding="utf-8") as f:
            for line in f:
                line = line.rstrip("\n")
                if not line or line.startswith("#"):
                    continue
                parts = line.split("\t")
                if len(parts) != 13:
                    continue
                try:
                    out.append((float(parts[0]), float(parts[1]), parts[4],
                                parts[5], float(parts[6]), float(parts[7]),
                                float(parts[8]), float(parts[9]),
                                float(parts[10]), parts[11], parts[12]))
                except ValueError:
                    continue
        return out

    def rewrite_history_file(self):
        """Rewrite the txt from the DB only (no import) — used after deletes
        like reset_paper so removed trades don't resurrect at next startup."""
        with self._lock:
            rows = self._db.execute(
                "SELECT opened,closed,mode,pair,qty,entry,exit,fee,pnl,"
                "reason_open,reason_close FROM trades WHERE status='closed' "
                "ORDER BY opened").fetchall()
        if rows or os.path.exists(self._history_path):
            with open(self._history_path, "w", encoding="utf-8") as f:
                f.write(self._HISTORY_HEADER)
                for r in rows:
                    f.write(self._history_fmt(r))

    def sync_history_file(self):
        """Import txt trades missing from the DB, then rewrite the file from
        the DB so both stay consistent. Called automatically at startup."""
        parsed = self._parse_history_file()
        with self._lock:
            rows = self._db.execute(
                "SELECT opened,closed,mode,pair,qty,entry,exit,fee,pnl,"
                "reason_open,reason_close FROM trades WHERE status='closed' "
                "ORDER BY opened").fetchall()
            known = {(r[2], r[3], round(r[0], 3)) for r in rows}
            imported = 0
            for t in parsed:
                if (t[2], t[3], round(t[0], 3)) in known:
                    continue
                self._db.execute(
                    "INSERT INTO trades(opened,closed,mode,pair,qty,entry,exit,"
                    "fee,pnl,status,reason_open,reason_close) "
                    "VALUES(?,?,?,?,?,?,?,?,?,'closed',?,?)", t)
                known.add((t[2], t[3], round(t[0], 3)))
                imported += 1
            if imported:
                self._db.commit()
            rows = self._db.execute(
                "SELECT opened,closed,mode,pair,qty,entry,exit,fee,pnl,"
                "reason_open,reason_close FROM trades WHERE status='closed' "
                "ORDER BY opened").fetchall()
        # Only create the file once there is (or was) something to record.
        if rows or os.path.exists(self._history_path):
            with open(self._history_path, "w", encoding="utf-8") as f:
                f.write(self._HISTORY_HEADER)
                for r in rows:
                    f.write(self._history_fmt(r))
        if imported:
            self.log("info", f"Imported {imported} trade(s) from trading_history.txt")
        return imported

    def trade_stats(self, mode):
        with self._lock:
            row = self._db.execute(
                "SELECT COUNT(*), COALESCE(SUM(pnl),0), "
                "SUM(CASE WHEN pnl>0 THEN 1 ELSE 0 END) "
                "FROM trades WHERE mode=? AND status='closed'", (mode,)).fetchone()
        return {"closed": row[0] or 0, "total_pnl": row[1] or 0.0, "wins": row[2] or 0}

    # ---- equity ----
    def snapshot_equity(self, mode, value):
        with self._lock:
            self._db.execute("INSERT INTO equity(ts,mode,value) VALUES(?,?,?)",
                             (time.time(), mode, value))
            self._db.commit()

    def equity_series(self, mode, limit=600):
        with self._lock:
            rows = self._db.execute(
                "SELECT ts,value FROM equity WHERE mode=? ORDER BY ts DESC LIMIT ?",
                (mode, limit)).fetchall()
        rows.reverse()
        return rows

    # ---- candle cache (for backtesting) ----
    def cached_candle_count(self, pair, gran, start_ts, end_ts):
        with self._lock:
            row = self._db.execute(
                "SELECT COUNT(*) FROM candles WHERE pair=? AND gran=? "
                "AND ts>=? AND ts<?", (pair, gran, start_ts, end_ts)).fetchone()
        return row[0]

    def save_candles(self, pair, gran, rows):
        """rows: iterable of [ts, low, high, open, close, vol]."""
        with self._lock:
            self._db.executemany(
                "INSERT OR REPLACE INTO candles(pair,gran,ts,low,high,open,close,vol) "
                "VALUES(?,?,?,?,?,?,?,?)",
                [(pair, gran, int(r[0]), r[1], r[2], r[3], r[4], r[5]) for r in rows])
            self._db.commit()

    def get_candles(self, pair, gran, start_ts, end_ts):
        """Cached candles oldest-first as [ts, low, high, open, close, vol]."""
        with self._lock:
            rows = self._db.execute(
                "SELECT ts,low,high,open,close,vol FROM candles "
                "WHERE pair=? AND gran=? AND ts>=? AND ts<? ORDER BY ts",
                (pair, gran, start_ts, end_ts)).fetchall()
        return [list(r) for r in rows]

    def reset_paper(self, start_cash):
        with self._lock:
            self._db.execute("DELETE FROM equity WHERE mode='paper'")
            self._db.execute("DELETE FROM trades WHERE mode='paper'")
            self._db.commit()
        self.save_paper_state({"cash": start_cash, "positions": {},
                               "baseline": start_cash})
        try:
            self.rewrite_history_file()  # drop deleted paper trades from the txt too
        except Exception:
            pass
        self.log("info", f"Paper account reset to ${start_cash:,.2f}")
