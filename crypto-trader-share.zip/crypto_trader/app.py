"""Crypto Trader GUI — dashboard, history, settings, and API key management."""

import datetime
import os
import queue
import subprocess
import sys
import threading
import time
import tkinter as tk
from tkinter import messagebox, ttk

from . import backtest
from . import notify
from . import secure
from .engine import Engine
from .store import Store

# Dark-theme palette (validated data-viz reference palette, dark mode)
PAGE = "#0d0d0d"       # window background
SURFACE = "#1a1a19"    # cards / chart surface
SURFACE2 = "#242423"   # headers, inputs
INK = "#ffffff"
INK2 = "#c3c2b7"
MUTED = "#898781"
GRID = "#2c2c2a"
BASELINE = "#383835"
BLUE = "#3987e5"       # series-1: strategy equity line
AQUA = "#199e70"       # series-2: buy & hold benchmark line
GOOD = "#0ca30c"
BAD = "#d03b3b"
WARN = "#fab219"

FONT = "Segoe UI"
PAIR_CHOICES = ["BTC-USD", "ETH-USD", "SOL-USD", "XRP-USD", "LTC-USD", "DOGE-USD"]


def fmt_money(v, sign=False):
    s = "+" if (sign and v >= 0) else ("−" if (sign and v < 0) else "")
    return f"{s}${abs(v):,.2f}"


def fmt_ts(ts):
    if not ts:
        return "—"
    return datetime.datetime.fromtimestamp(ts).strftime("%m-%d %H:%M")


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Crypto Trader")
        self.geometry("1050x780")
        self.minsize(880, 640)
        self.configure(bg=PAGE)

        self.store = Store()
        self.events = queue.Queue()
        self.engine = Engine(self.store, self.events)
        self.status = None

        self._style()
        self._build_header()
        self._build_tabs()

        self.engine.start()
        self.bt_q = queue.Queue()
        self.bt_result = None
        self.after(400, self._drain_events)
        self.after(300, self._bt_poll)
        self.after(1500, self._history_loop)
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self._log_line("info", "App started. Press ▶ Start to begin trading "
                               f"({self.engine.cfg['mode']} mode).")

    # ---------- styling ----------
    def _style(self):
        st = ttk.Style(self)
        st.theme_use("clam")
        st.configure("TNotebook", background=PAGE, borderwidth=0)
        st.configure("TNotebook.Tab", background=SURFACE, foreground=INK2,
                     padding=(18, 8), font=(FONT, 10))
        st.map("TNotebook.Tab",
               background=[("selected", SURFACE2)],
               foreground=[("selected", INK)])
        st.configure("Treeview", background=SURFACE, fieldbackground=SURFACE,
                     foreground=INK2, borderwidth=0, rowheight=24,
                     font=(FONT, 9))
        st.configure("Treeview.Heading", background=SURFACE2, foreground=INK2,
                     borderwidth=0, font=(FONT, 9, "bold"))
        st.map("Treeview", background=[("selected", "#1c3a5e")],
               foreground=[("selected", INK)])
        st.configure("Vertical.TScrollbar", background=SURFACE2,
                     troughcolor=SURFACE, borderwidth=0, arrowcolor=MUTED)
        st.configure("Horizontal.TScrollbar", background=SURFACE2,
                     troughcolor=SURFACE, borderwidth=0, arrowcolor=MUTED)

    def _card(self, parent, **kw):
        return tk.Frame(parent, bg=SURFACE, highlightbackground=GRID,
                        highlightthickness=1, **kw)

    def _btn(self, parent, text, command, bg=SURFACE2, fg=INK, **kw):
        return tk.Button(parent, text=text, command=command, bg=bg, fg=fg,
                         activebackground=GRID, activeforeground=INK,
                         relief="flat", font=(FONT, 10, "bold"),
                         padx=14, pady=6, cursor="hand2", **kw)

    # ---------- header ----------
    def _build_header(self):
        h = tk.Frame(self, bg=PAGE)
        h.pack(fill="x", padx=14, pady=(12, 4))
        tk.Label(h, text="Crypto Trader", bg=PAGE, fg=INK,
                 font=(FONT, 16, "bold")).pack(side="left")
        self.mode_badge = tk.Label(h, text=" PAPER ", bg=BLUE, fg=INK,
                                   font=(FONT, 9, "bold"), padx=8, pady=2)
        self.mode_badge.pack(side="left", padx=12)
        self.state_lbl = tk.Label(h, text="paused", bg=PAGE, fg=MUTED,
                                  font=(FONT, 10))
        self.state_lbl.pack(side="left", padx=4)

        conn = tk.Frame(h, bg=PAGE)
        conn.pack(side="right")
        self.conn_dot = tk.Canvas(conn, width=12, height=12, bg=PAGE,
                                  highlightthickness=0)
        self.conn_dot.pack(side="left", pady=2)
        self._dot = self.conn_dot.create_oval(2, 2, 11, 11, fill=MUTED, outline="")
        self.conn_lbl = tk.Label(conn, text="connecting…", bg=PAGE, fg=MUTED,
                                 font=(FONT, 9))
        self.conn_lbl.pack(side="left", padx=(6, 0))

    # ---------- tabs ----------
    def _build_tabs(self):
        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True, padx=14, pady=(6, 12))
        self.tab_dash = tk.Frame(self.nb, bg=PAGE)
        self.tab_bt = tk.Frame(self.nb, bg=PAGE)
        self.tab_hist = tk.Frame(self.nb, bg=PAGE)
        self.tab_set = tk.Frame(self.nb, bg=PAGE)
        self.tab_keys = tk.Frame(self.nb, bg=PAGE)
        self.nb.add(self.tab_dash, text="Dashboard")
        self.nb.add(self.tab_bt, text="Backtest")
        self.nb.add(self.tab_hist, text="History")
        self.nb.add(self.tab_set, text="Settings")
        self.nb.add(self.tab_keys, text="API Keys")
        self._build_dashboard()
        self._build_backtest()
        self._build_history()
        self._build_settings()
        self._build_keys()

    # ---------- dashboard ----------
    def _build_dashboard(self):
        t = self.tab_dash

        ctrl = tk.Frame(t, bg=PAGE)
        ctrl.pack(fill="x", pady=(10, 6))
        self.start_btn = self._btn(ctrl, "▶  Start", self._cmd_start, bg="#0d4d0d")
        self.start_btn.pack(side="left", padx=(2, 6))
        self._btn(ctrl, "❚❚  Pause", self._cmd_pause).pack(side="left", padx=6)
        self._btn(ctrl, "⏻  Sell everything & stop", self._cmd_flatten,
                  bg=BAD).pack(side="right", padx=2)

        tiles = tk.Frame(t, bg=PAGE)
        tiles.pack(fill="x", pady=6)
        self.tile_vals = {}
        for i, (key, label) in enumerate([
                ("equity", "Equity"), ("day", "Today's P&L"),
                ("total", "Total P&L"), ("winrate", "Closed trades"),
                ("drawdown", "Max drawdown")]):
            card = self._card(tiles)
            card.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 8, 0))
            tiles.columnconfigure(i, weight=1)
            tk.Label(card, text=label.upper(), bg=SURFACE, fg=MUTED,
                     font=(FONT, 8, "bold")).pack(anchor="w", padx=12, pady=(10, 0))
            v = tk.Label(card, text="—", bg=SURFACE, fg=INK, font=(FONT, 18, "bold"))
            v.pack(anchor="w", padx=12, pady=(0, 2))
            s = tk.Label(card, text="", bg=SURFACE, fg=MUTED, font=(FONT, 9))
            s.pack(anchor="w", padx=12, pady=(0, 10))
            self.tile_vals[key] = (v, s)

        prices = self._card(t)
        prices.pack(fill="x", pady=6)
        self.price_row = tk.Frame(prices, bg=SURFACE)
        self.price_row.pack(fill="x", padx=12, pady=8)
        self.price_lbls = {}

        chart_card = self._card(t)
        chart_card.pack(fill="x", pady=6)
        tk.Label(chart_card, text="EQUITY", bg=SURFACE, fg=MUTED,
                 font=(FONT, 8, "bold")).pack(anchor="w", padx=12, pady=(8, 0))
        self.chart = tk.Canvas(chart_card, height=150, bg=SURFACE,
                               highlightthickness=0)
        self.chart.pack(fill="x", padx=12, pady=(2, 10))
        self.chart.bind("<Configure>", lambda e: self._draw_chart())

        mid = tk.Frame(t, bg=PAGE)
        mid.pack(fill="both", expand=True, pady=6)
        mid.columnconfigure(0, weight=5)
        mid.columnconfigure(1, weight=4)
        mid.rowconfigure(0, weight=1)

        pos_card = self._card(mid)
        pos_card.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        tk.Label(pos_card, text="OPEN POSITIONS", bg=SURFACE, fg=MUTED,
                 font=(FONT, 8, "bold")).pack(anchor="w", padx=12, pady=(8, 4))
        cols = ("pair", "qty", "entry", "now", "stop", "pnl")
        self.pos_tree = ttk.Treeview(pos_card, columns=cols, show="headings",
                                     height=4)
        for c, w, txt in [("pair", 80, "Pair"), ("qty", 90, "Qty"),
                          ("entry", 90, "Entry"), ("now", 90, "Now"),
                          ("stop", 90, "Stop"), ("pnl", 110, "Unrealized")]:
            self.pos_tree.heading(c, text=txt)
            self.pos_tree.column(c, width=w, anchor="e" if c != "pair" else "w")
        self.pos_tree.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self.pos_tree.tag_configure("up", foreground=GOOD)
        self.pos_tree.tag_configure("down", foreground=BAD)

        log_card = self._card(mid)
        log_card.grid(row=0, column=1, sticky="nsew")
        tk.Label(log_card, text="ACTIVITY", bg=SURFACE, fg=MUTED,
                 font=(FONT, 8, "bold")).pack(anchor="w", padx=12, pady=(8, 4))
        self.log_text = tk.Text(log_card, bg=SURFACE, fg=INK2, height=8,
                                relief="flat", font=("Consolas", 8),
                                wrap="word", state="disabled")
        self.log_text.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self.log_text.tag_configure("error", foreground=BAD)
        self.log_text.tag_configure("warn", foreground=WARN)
        self.log_text.tag_configure("trade", foreground=BLUE)
        self.log_text.tag_configure("muted", foreground=MUTED)

    # ---------- history ----------
    def _build_history(self):
        t = self.tab_hist
        top = tk.Frame(t, bg=PAGE)
        top.pack(fill="x", pady=(10, 4))
        tk.Label(top, text="Trades", bg=PAGE, fg=INK, font=(FONT, 11, "bold")
                 ).pack(side="left", padx=2)
        self._btn(top, "Refresh", self._refresh_history).pack(side="right")

        cols = ("opened", "closed", "mode", "pair", "qty", "entry", "exit",
                "fee", "pnl", "why_open", "why_close")
        frame1 = self._card(t)
        frame1.pack(fill="both", expand=True, pady=4)
        self.trades_tree = ttk.Treeview(frame1, columns=cols, show="headings",
                                        height=8)
        widths = {"opened": 85, "closed": 85, "mode": 50, "pair": 70, "qty": 90,
                  "entry": 85, "exit": 85, "fee": 65, "pnl": 85,
                  "why_open": 200, "why_close": 170}
        heads = {"opened": "Opened", "closed": "Closed", "mode": "Mode",
                 "pair": "Pair", "qty": "Qty", "entry": "Entry", "exit": "Exit",
                 "fee": "Fees", "pnl": "P&L", "why_open": "Why opened",
                 "why_close": "Why closed"}
        for c in cols:
            self.trades_tree.heading(c, text=heads[c])
            self.trades_tree.column(c, width=widths[c],
                                    anchor="w" if "why" in c or c in ("mode", "pair") else "e")
        xs = ttk.Scrollbar(frame1, orient="horizontal",
                           command=self.trades_tree.xview)
        self.trades_tree.configure(xscrollcommand=xs.set)
        self.trades_tree.pack(fill="both", expand=True, padx=6, pady=(6, 0))
        xs.pack(fill="x", padx=6, pady=(0, 6))
        self.trades_tree.tag_configure("up", foreground=GOOD)
        self.trades_tree.tag_configure("down", foreground=BAD)

        tk.Label(t, text="Action log", bg=PAGE, fg=INK, font=(FONT, 11, "bold")
                 ).pack(anchor="w", padx=2, pady=(8, 4))
        frame2 = self._card(t)
        frame2.pack(fill="both", expand=True, pady=(0, 8))
        self.actions_tree = ttk.Treeview(
            frame2, columns=("ts", "level", "msg"), show="headings", height=8)
        for c, w, txt in [("ts", 110, "Time"), ("level", 60, "Level"),
                          ("msg", 700, "What happened")]:
            self.actions_tree.heading(c, text=txt)
            self.actions_tree.column(c, width=w, anchor="w")
        ys = ttk.Scrollbar(frame2, orient="vertical",
                           command=self.actions_tree.yview)
        self.actions_tree.configure(yscrollcommand=ys.set)
        ys.pack(side="right", fill="y", padx=(0, 4), pady=6)
        self.actions_tree.pack(fill="both", expand=True, padx=6, pady=6)
        self.actions_tree.tag_configure("error", foreground=BAD)
        self.actions_tree.tag_configure("warn", foreground=WARN)
        self.actions_tree.tag_configure("trade", foreground=BLUE)

    # ---------- settings ----------
    def _build_settings(self):
        t = self.tab_set
        cfg = self.engine.cfg
        wrap = self._card(t)
        wrap.pack(fill="x", pady=10, padx=2, anchor="n")
        grid = tk.Frame(wrap, bg=SURFACE)
        grid.pack(padx=16, pady=14, anchor="w")

        def field(row, col, label, value, hint=""):
            tk.Label(grid, text=label, bg=SURFACE, fg=INK2, font=(FONT, 9)
                     ).grid(row=row, column=col * 2, sticky="w", pady=5, padx=(0, 8))
            var = tk.StringVar(value=str(value))
            e = tk.Entry(grid, textvariable=var, bg=SURFACE2, fg=INK, width=10,
                         relief="flat", insertbackground=INK, font=(FONT, 10))
            e.grid(row=row, column=col * 2 + 1, sticky="w", padx=(0, 30))
            if hint:
                tk.Label(grid, text=hint, bg=SURFACE, fg=MUTED, font=(FONT, 8)
                         ).grid(row=row + 1, column=col * 2 + 1, sticky="w",
                                padx=(0, 30))
            return var

        self.v_risk = field(0, 0, "Risk per trade (%)", cfg["risk_per_trade"] * 100,
                            "of account, per position")
        self.v_halt = field(0, 1, "Daily loss halt (%)", cfg["daily_halt"] * 100,
                            "stop for the day if down this much")
        self.v_maxpos = field(0, 2, "Max position (%)", cfg["max_pos_frac"] * 100,
                              "of account in one coin")
        self.v_stop = field(2, 0, "Initial stop (ATRs)", cfg["stop_atr"])
        self.v_trail = field(2, 1, "Trailing stop (ATRs)", cfg["trail_atr"])
        self.v_poll = field(2, 2, "Check every (sec)", cfg["poll_seconds"])
        self.v_fee = field(4, 0, "Taker fee (%)", cfg["fee_rate"] * 100,
                           "market orders — check your Coinbase tier")
        self.v_cash = field(4, 1, "Paper start cash ($)", cfg["paper_start_cash"])
        self.v_makerfee = field(4, 2, "Maker fee (%)", cfg["maker_fee"] * 100,
                                "limit orders — usually half the taker fee")

        self.v_trendfilter = tk.BooleanVar(value=cfg.get("trend_filter", True))
        tk.Checkbutton(grid, text="Skip buys in downtrends (EMA200 regime filter "
                                  "— recommended)",
                       variable=self.v_trendfilter, bg=SURFACE, fg=INK2,
                       selectcolor=SURFACE2, activebackground=SURFACE,
                       activeforeground=INK, font=(FONT, 9)
                       ).grid(row=6, column=0, columnspan=4, sticky="w", pady=(10, 0))
        self.v_prefermaker = tk.BooleanVar(value=cfg.get("prefer_maker", True))
        tk.Checkbutton(grid, text="Prefer limit orders for cheaper maker fees "
                                  "(recommended; urgent stop-sells always use "
                                  "market orders)",
                       variable=self.v_prefermaker, bg=SURFACE, fg=INK2,
                       selectcolor=SURFACE2, activebackground=SURFACE,
                       activeforeground=INK, font=(FONT, 9)
                       ).grid(row=7, column=0, columnspan=4, sticky="w", pady=(4, 0))

        tk.Label(grid, text="Candle timeframe", bg=SURFACE, fg=INK2,
                 font=(FONT, 9)).grid(row=8, column=0, sticky="w", pady=(10, 0))
        tf_row = tk.Frame(grid, bg=SURFACE)
        tf_row.grid(row=8, column=1, columnspan=5, sticky="w", pady=(10, 0))
        self.v_gran = tk.StringVar(value=str(cfg["granularity"]))
        for sec, txt in [("3600", "1 hour (trades often — fees add up)"),
                         ("21600", "6 hours (backtested best)"),
                         ("86400", "1 day (slowest, smallest drawdowns)")]:
            tk.Radiobutton(tf_row, text=txt, value=sec, variable=self.v_gran,
                           bg=SURFACE, fg=INK2, selectcolor=SURFACE2,
                           activebackground=SURFACE, activeforeground=INK,
                           font=(FONT, 9)).pack(side="left", padx=(0, 14))

        pairs_card = self._card(t)
        pairs_card.pack(fill="x", pady=6, padx=2)
        tk.Label(pairs_card, text="COINS TO TRADE", bg=SURFACE, fg=MUTED,
                 font=(FONT, 8, "bold")).pack(anchor="w", padx=16, pady=(10, 2))
        row = tk.Frame(pairs_card, bg=SURFACE)
        row.pack(anchor="w", padx=16, pady=(0, 12))
        self.pair_vars = {}
        for p in PAIR_CHOICES:
            var = tk.BooleanVar(value=p in cfg["pairs"])
            cb = tk.Checkbutton(row, text=p.split("-")[0], variable=var,
                                bg=SURFACE, fg=INK2, selectcolor=SURFACE2,
                                activebackground=SURFACE, activeforeground=INK,
                                font=(FONT, 10))
            cb.pack(side="left", padx=(0, 14))
            self.pair_vars[p] = var

        mode_card = self._card(t)
        mode_card.pack(fill="x", pady=6, padx=2)
        tk.Label(mode_card, text="TRADING MODE", bg=SURFACE, fg=MUTED,
                 font=(FONT, 8, "bold")).pack(anchor="w", padx=16, pady=(10, 2))
        mrow = tk.Frame(mode_card, bg=SURFACE)
        mrow.pack(anchor="w", padx=16, pady=(0, 12))
        self.v_mode = tk.StringVar(value=cfg["mode"])
        for val, txt in [("paper", "Paper trading (fake money, real prices — safe)"),
                         ("live", "LIVE trading (real money on Coinbase)")]:
            tk.Radiobutton(mrow, text=txt, value=val, variable=self.v_mode,
                           bg=SURFACE, fg=INK2, selectcolor=SURFACE2,
                           activebackground=SURFACE, activeforeground=INK,
                           font=(FONT, 10)).pack(anchor="w", pady=2)

        notif_card = self._card(t)
        notif_card.pack(fill="x", pady=6, padx=2)
        tk.Label(notif_card, text="PHONE NOTIFICATIONS (OPTIONAL)", bg=SURFACE,
                 fg=MUTED, font=(FONT, 8, "bold")).pack(anchor="w", padx=16,
                                                        pady=(10, 2))
        nrow = tk.Frame(notif_card, bg=SURFACE)
        nrow.pack(anchor="w", padx=16, pady=(0, 12), fill="x")

        def nfield(col, label, value, width=22):
            tk.Label(nrow, text=label, bg=SURFACE, fg=INK2, font=(FONT, 9)
                     ).grid(row=0, column=col, sticky="w", padx=(0, 6))
            var = tk.StringVar(value=value)
            tk.Entry(nrow, textvariable=var, bg=SURFACE2, fg=INK, width=width,
                     relief="flat", insertbackground=INK, font=(FONT, 9)
                     ).grid(row=1, column=col, sticky="w", padx=(0, 18))
            return var

        self.v_ntfy = nfield(0, "ntfy.sh topic (easiest — install the ntfy app)",
                             cfg.get("ntfy_topic", ""))
        self.v_tgtok = nfield(1, "Telegram bot token", cfg.get("telegram_token", ""))
        self.v_tgchat = nfield(2, "Telegram chat id", cfg.get("telegram_chat", ""),
                               width=14)
        self._btn(nrow, "Send test", self._test_notify).grid(
            row=1, column=3, sticky="w")

        btns = tk.Frame(t, bg=PAGE)
        btns.pack(fill="x", pady=10, padx=2)
        self._btn(btns, "💾  Save & apply", self._save_settings,
                  bg="#1c3a5e").pack(side="left")
        self.startup_btn = self._btn(btns, "", self._toggle_startup)
        self.startup_btn.pack(side="left", padx=10)
        self._update_startup_btn()
        self._btn(btns, "Reset paper account", self._reset_paper
                  ).pack(side="right")

    # ---------- notifications & startup ----------
    def _test_notify(self):
        cfg = {"ntfy_topic": self.v_ntfy.get().strip(),
               "telegram_token": self.v_tgtok.get().strip(),
               "telegram_chat": self.v_tgchat.get().strip()}
        if not notify.configured(cfg):
            messagebox.showinfo(
                "Nothing configured",
                "Fill in an ntfy.sh topic (easiest: pick any unique name like "
                "'my-trader-8271', install the ntfy app on your phone, and "
                "subscribe to that same topic) or Telegram bot details first.")
            return
        notify.send_async(cfg, "Crypto Trader",
                          "Test notification — you're connected! 🎉")
        self._log_line("info", "Test notification sent — check your phone. "
                               "Remember to Save & apply so the bot uses it.")

    def _startup_lnk(self):
        return os.path.join(os.environ["APPDATA"],
                            r"Microsoft\Windows\Start Menu\Programs\Startup",
                            "Crypto Trader.lnk")

    def _update_startup_btn(self):
        on = os.path.exists(self._startup_lnk())
        self.startup_btn.config(
            text="✓ Starts with Windows (click to disable)" if on
            else "Start with Windows: off (click to enable)")

    def _toggle_startup(self):
        lnk = self._startup_lnk()
        if os.path.exists(lnk):
            os.remove(lnk)
            self._log_line("info", "Removed from Windows startup.")
        else:
            root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            pyw = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
            if not os.path.exists(pyw):
                pyw = sys.executable
            script = os.path.join(root, "run_trader.pyw")
            ps = (f"$ws=New-Object -ComObject WScript.Shell; "
                  f"$sc=$ws.CreateShortcut('{lnk}'); "
                  f"$sc.TargetPath='{pyw}'; "
                  f"$sc.Arguments='\"{script}\"'; "
                  f"$sc.WorkingDirectory='{root}'; $sc.Save()")
            subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                           creationflags=0x08000000)  # no console window
            self._log_line("info", "Added to Windows startup — the bot will "
                                   "open when you log in.")
        self._update_startup_btn()

    # ---------- backtest tab ----------
    def _build_backtest(self):
        t = self.tab_bt
        ctrl = self._card(t)
        ctrl.pack(fill="x", pady=(10, 6), padx=2)
        row = tk.Frame(ctrl, bg=SURFACE)
        row.pack(anchor="w", padx=16, pady=10)

        tk.Label(row, text="Years back", bg=SURFACE, fg=INK2, font=(FONT, 9)
                 ).pack(side="left")
        self.bt_years = tk.StringVar(value="2")
        tk.Entry(row, textvariable=self.bt_years, width=5, bg=SURFACE2, fg=INK,
                 relief="flat", insertbackground=INK).pack(side="left", padx=(6, 18))
        tk.Label(row, text="Start cash ($)", bg=SURFACE, fg=INK2, font=(FONT, 9)
                 ).pack(side="left")
        self.bt_cash = tk.StringVar(value=str(int(self.engine.cfg["paper_start_cash"])))
        tk.Entry(row, textvariable=self.bt_cash, width=8, bg=SURFACE2, fg=INK,
                 relief="flat", insertbackground=INK).pack(side="left", padx=(6, 18))
        self.bt_filter = tk.BooleanVar(value=self.engine.cfg.get("trend_filter", True))
        tk.Checkbutton(row, text="EMA200 filter", variable=self.bt_filter,
                       bg=SURFACE, fg=INK2, selectcolor=SURFACE2,
                       activebackground=SURFACE, activeforeground=INK,
                       font=(FONT, 9)).pack(side="left", padx=(0, 12))
        self.bt_maker = tk.BooleanVar(value=self.engine.cfg.get("prefer_maker", True))
        tk.Checkbutton(row, text="Maker fees", variable=self.bt_maker,
                       bg=SURFACE, fg=INK2, selectcolor=SURFACE2,
                       activebackground=SURFACE, activeforeground=INK,
                       font=(FONT, 9)).pack(side="left", padx=(0, 12))
        self.bt_btn = self._btn(row, "▶  Run backtest", self._run_backtest,
                                bg="#1c3a5e")
        self.bt_btn.pack(side="left", padx=8)
        self.bt_prog = tk.Label(ctrl, text="Replays your current Settings "
                                           "(strategy, risk, fees, coins) over real "
                                           "historical prices. First run downloads "
                                           "data; repeats are instant.",
                                bg=SURFACE, fg=MUTED, font=(FONT, 9))
        self.bt_prog.pack(anchor="w", padx=16, pady=(0, 10))

        chart_card = self._card(t)
        chart_card.pack(fill="x", pady=6, padx=2)
        tk.Label(chart_card, text="EQUITY — STRATEGY VS BUY & HOLD", bg=SURFACE,
                 fg=MUTED, font=(FONT, 8, "bold")).pack(anchor="w", padx=12,
                                                        pady=(8, 0))
        self.bt_canvas = tk.Canvas(chart_card, height=200, bg=SURFACE,
                                   highlightthickness=0)
        self.bt_canvas.pack(fill="x", padx=12, pady=(2, 10))
        self.bt_canvas.bind("<Configure>", lambda e: self._draw_bt_chart())

        res_card = self._card(t)
        res_card.pack(fill="both", expand=True, pady=6, padx=2)
        self.bt_metrics = tk.Frame(res_card, bg=SURFACE)
        self.bt_metrics.pack(fill="x", padx=16, pady=12, anchor="w")
        tk.Label(self.bt_metrics, text="No backtest run yet.", bg=SURFACE,
                 fg=MUTED, font=(FONT, 10)).pack(anchor="w")

    def _run_backtest(self):
        try:
            years = min(6.0, max(0.1, float(self.bt_years.get())))
            cash = max(10.0, float(self.bt_cash.get()))
        except ValueError:
            messagebox.showerror("Invalid value", "Years and cash must be numbers.")
            return
        cfg = self.store.load_settings()
        use_filter = bool(self.bt_filter.get())
        use_maker = bool(self.bt_maker.get())
        self.bt_btn.config(state="disabled")
        self.bt_prog.config(text="Starting…", fg=INK2)

        def work():
            try:
                end = time.time()
                start = end - years * 365.25 * 86400
                res = backtest.run_backtest(
                    self.store, cfg, cfg["pairs"], start, end, cash,
                    trend_filter=use_filter, prefer_maker=use_maker,
                    progress=lambda f, m: self.bt_q.put(("prog", f, m)))
                self.bt_q.put(("done", res, None))
            except Exception as e:
                self.bt_q.put(("done", None, str(e)))
        threading.Thread(target=work, daemon=True).start()

    def _bt_poll(self):
        try:
            while True:
                item = self.bt_q.get_nowait()
                if item[0] == "prog":
                    self.bt_prog.config(text=f"{item[1] * 100:.0f}%  {item[2]}",
                                        fg=INK2)
                elif item[0] == "done":
                    self.bt_btn.config(state="normal")
                    if item[2]:
                        self.bt_prog.config(text=f"Backtest failed: {item[2]}",
                                            fg=BAD)
                    else:
                        self.bt_result = item[1]
                        self.bt_prog.config(text="Done.", fg=GOOD)
                        self._render_bt_metrics()
                        self._draw_bt_chart()
        except queue.Empty:
            pass
        self.after(250, self._bt_poll)

    def _render_bt_metrics(self):
        for w in self.bt_metrics.winfo_children():
            w.destroy()
        r = self.bt_result
        s, b = r["strategy"], r["buyhold"]

        def pct(x):
            return f"{'+' if x >= 0 else '−'}{abs(x) * 100:.1f}%"

        def money(x):
            return fmt_money(x)

        headers = ["", "Strategy", "Buy & hold"]
        rows = [
            ("Final value", money(s["final"]), money(b["final"])),
            ("Total return", pct(s["total_return"]), pct(b["total_return"])),
            ("Yearly (CAGR)", pct(s["cagr"]), pct(b["cagr"])),
            ("Max drawdown", f"−{s['max_dd'] * 100:.1f}%",
             f"−{b['max_dd'] * 100:.1f}%"),
            ("Trades", str(s["n_trades"]), "1"),
            ("Win rate", f"{s['win_rate'] * 100:.0f}%" if s["n_trades"] else "—", "—"),
            ("Avg win / loss", (f"{money(s['avg_win'])} / {money(s['avg_loss'])}"
                                if s["n_trades"] else "—"), "—"),
            ("Total fees", money(s["fees"]), "—"),
        ]
        for c, htxt in enumerate(headers):
            tk.Label(self.bt_metrics, text=htxt, bg=SURFACE, fg=MUTED,
                     font=(FONT, 9, "bold")).grid(row=0, column=c, sticky="w",
                                                  padx=(0, 28), pady=(0, 4))
        for ri, (name, sv, bv) in enumerate(rows, start=1):
            tk.Label(self.bt_metrics, text=name, bg=SURFACE, fg=INK2,
                     font=(FONT, 9)).grid(row=ri, column=0, sticky="w",
                                          padx=(0, 28), pady=1)
            for ci, val in ((1, sv), (2, bv)):
                fg = INK
                if name in ("Total return", "Yearly (CAGR)") and val != "—":
                    fg = GOOD if val.startswith("+") else BAD
                tk.Label(self.bt_metrics, text=val, bg=SURFACE, fg=fg,
                         font=(FONT, 9, "bold")).grid(row=ri, column=ci,
                                                      sticky="w", padx=(0, 28),
                                                      pady=1)
        note = (f"Consistency check — strategy first half {pct(s['first_half'])}, "
                f"second half {pct(s['second_half'])}. If one half carries all the "
                f"profit, be skeptical: the edge may not persist.")
        tk.Label(self.bt_metrics, text=note, bg=SURFACE, fg=MUTED,
                 font=(FONT, 8), wraplength=760, justify="left"
                 ).grid(row=len(rows) + 1, column=0, columnspan=3, sticky="w",
                        pady=(8, 0))

    def _draw_bt_chart(self):
        c = self.bt_canvas
        c.delete("all")
        w = c.winfo_width()
        h = int(c["height"])
        if w < 60:
            return
        if not self.bt_result:
            c.create_text(w // 2, h // 2, text="Run a backtest to see the "
                                               "equity curves.",
                          fill=MUTED, font=(FONT, 9))
            return
        curves = [("Strategy", self.bt_result["curve"], BLUE),
                  ("Buy & hold", self.bt_result["bench"], AQUA)]
        pad_l, pad_r, pad_t, pad_b = 8, 64, 26, 18
        xs0, xs1 = pad_l, w - pad_r
        ys0, ys1 = pad_t, h - pad_b
        all_vals = [v for _, series, _ in curves for _, v in series]
        vmin, vmax = min(all_vals), max(all_vals)
        if vmax - vmin < 1e-9:
            vmin -= 1; vmax += 1
        span = vmax - vmin
        t_min = curves[0][1][0][0]
        t_max = curves[0][1][-1][0]

        for frac in (0.0, 0.5, 1.0):
            y = ys1 - frac * (ys1 - ys0)
            c.create_line(xs0, y, xs1, y, fill=GRID)
            c.create_text(xs1 + 6, y, anchor="w", fill=MUTED, font=(FONT, 8),
                          text=f"${vmin + frac * span:,.0f}")

        for name, series, color in curves:
            n = len(series)
            step = max(1, n // 900)
            pts = []
            for i in range(0, n, step):
                ts, v = series[i]
                x = xs0 + (xs1 - xs0) * (ts - t_min) / max(1, t_max - t_min)
                y = ys1 - (v - vmin) / span * (ys1 - ys0)
                pts.extend((x, y))
            if len(pts) >= 4:
                c.create_line(*pts, fill=color, width=2)

        # legend (two series — required)
        lx = xs0 + 4
        for name, _, color in curves:
            c.create_rectangle(lx, 8, lx + 10, 18, fill=color, outline="")
            c.create_text(lx + 15, 13, anchor="w", fill=INK2, font=(FONT, 8),
                          text=name)
            lx += 15 + 8 * len(name) + 24

        d0 = datetime.datetime.fromtimestamp(t_min)
        d1 = datetime.datetime.fromtimestamp(t_max)
        c.create_text(xs0, h - 6, anchor="w", fill=MUTED, font=(FONT, 8),
                      text=d0.strftime("%b %Y"))
        c.create_text(xs1, h - 6, anchor="e", fill=MUTED, font=(FONT, 8),
                      text=d1.strftime("%b %Y"))

    # ---------- api keys ----------
    def _build_keys(self):
        t = self.tab_keys
        card = self._card(t)
        card.pack(fill="both", expand=True, pady=10, padx=2)
        inner = tk.Frame(card, bg=SURFACE)
        inner.pack(fill="both", expand=True, padx=18, pady=14)

        intro = ("Paste your Coinbase API key here (create one at "
                 "portal.cdp.coinbase.com → API keys).\n"
                 "IMPORTANT: give the key View and Trade permission ONLY — "
                 "never Transfer/Withdraw.\n"
                 "Keys are encrypted with Windows DPAPI, tied to your Windows "
                 "login; they are never stored as plain text.")
        tk.Label(inner, text=intro, bg=SURFACE, fg=INK2, justify="left",
                 font=(FONT, 9)).pack(anchor="w", pady=(0, 12))

        tk.Label(inner, text="API key name  (organizations/…/apiKeys/…)",
                 bg=SURFACE, fg=MUTED, font=(FONT, 8, "bold")).pack(anchor="w")
        self.key_name = tk.Entry(inner, bg=SURFACE2, fg=INK, relief="flat",
                                 insertbackground=INK, font=("Consolas", 9),
                                 width=80)
        self.key_name.pack(anchor="w", fill="x", pady=(2, 10))

        tk.Label(inner, text="Private key  (-----BEGIN EC PRIVATE KEY----- …)",
                 bg=SURFACE, fg=MUTED, font=(FONT, 8, "bold")).pack(anchor="w")
        self.key_secret = tk.Text(inner, bg=SURFACE2, fg=INK, relief="flat",
                                  insertbackground=INK, font=("Consolas", 9),
                                  height=6, width=80)
        self.key_secret.pack(anchor="w", fill="x", pady=(2, 10))

        row = tk.Frame(inner, bg=SURFACE)
        row.pack(anchor="w", pady=4)
        self._btn(row, "💾  Save keys (encrypted)", self._save_keys,
                  bg="#1c3a5e").pack(side="left", padx=(0, 10))
        self.test_btn = self._btn(row, "Test connection", self._test_keys)
        self.test_btn.pack(side="left", padx=(0, 10))
        self._btn(row, "Delete saved keys", self._delete_keys).pack(side="left")

        self.keys_status = tk.Label(inner, text="", bg=SURFACE, fg=MUTED,
                                    font=(FONT, 9))
        self.keys_status.pack(anchor="w", pady=8)
        self._update_keys_status()

    def _update_keys_status(self):
        saved = bool(self.store.get("cb_key_name"))
        self.keys_status.config(
            text=("✓ Keys are saved (encrypted). Fields above stay blank for "
                  "your security — paste again to replace." if saved
                  else "No API keys saved yet. Paper trading works without them."),
            fg=GOOD if saved else MUTED)

    # ---------- commands ----------
    def _cmd_start(self):
        cfg = self.engine.cfg
        if cfg["mode"] == "live" and not self.store.get("cb_key_name"):
            messagebox.showerror("No API keys",
                                 "Live mode needs Coinbase API keys — add them "
                                 "in the API Keys tab, or switch to paper mode.")
            return
        self.engine.commands.put(("start",))

    def _cmd_pause(self):
        self.engine.commands.put(("pause",))

    def _cmd_flatten(self):
        if messagebox.askyesno(
                "Emergency stop",
                "Sell ALL open positions at market price right now and pause "
                "the bot?\n\nThis is immediate and cannot be undone."):
            self.engine.commands.put(("flatten",))

    def _reset_paper(self):
        if messagebox.askyesno(
                "Reset paper account",
                "Erase all paper trades and equity history and restart the "
                "paper account at the starting cash amount?"):
            self.engine.commands.put(("reset_paper",))
            self.after(800, self._refresh_history)

    def _save_settings(self):
        try:
            cfg = self.store.load_settings()
            cfg["risk_per_trade"] = max(0.001, min(0.05, float(self.v_risk.get()) / 100))
            cfg["daily_halt"] = max(0.01, min(0.5, float(self.v_halt.get()) / 100))
            cfg["max_pos_frac"] = max(0.05, min(1.0, float(self.v_maxpos.get()) / 100))
            cfg["stop_atr"] = max(0.5, float(self.v_stop.get()))
            cfg["trail_atr"] = max(0.5, float(self.v_trail.get()))
            cfg["poll_seconds"] = max(15, int(float(self.v_poll.get())))
            cfg["fee_rate"] = max(0.0, float(self.v_fee.get()) / 100)
            cfg["maker_fee"] = max(0.0, float(self.v_makerfee.get()) / 100)
            cfg["paper_start_cash"] = max(10.0, float(self.v_cash.get()))
            cfg["trend_filter"] = bool(self.v_trendfilter.get())
            cfg["prefer_maker"] = bool(self.v_prefermaker.get())
            cfg["granularity"] = int(self.v_gran.get())
            cfg["ntfy_topic"] = self.v_ntfy.get().strip()
            cfg["telegram_token"] = self.v_tgtok.get().strip()
            cfg["telegram_chat"] = self.v_tgchat.get().strip()
        except ValueError:
            messagebox.showerror("Invalid value",
                                 "One of the settings isn't a number — "
                                 "please check and try again.")
            return
        pairs = [p for p, v in self.pair_vars.items() if v.get()]
        if not pairs:
            messagebox.showerror("No coins", "Select at least one coin to trade.")
            return
        cfg["pairs"] = pairs

        new_mode = self.v_mode.get()
        if new_mode == "live" and cfg["mode"] != "live":
            if not self.store.get("cb_key_name"):
                messagebox.showerror("No API keys",
                                     "Add your Coinbase API keys in the API Keys "
                                     "tab before enabling live trading.")
                self.v_mode.set("paper")
                return
            if self.engine.positions:
                messagebox.showerror("Open positions",
                                     "Close (or emergency-sell) your paper "
                                     "positions before switching to live.")
                self.v_mode.set("paper")
                return
            if not messagebox.askyesno(
                    "⚠ Enable LIVE trading?",
                    "The bot will trade REAL money on your Coinbase account.\n\n"
                    "Only proceed if the paper results have satisfied you and "
                    "you can afford to lose what's in the account.\n\n"
                    "Enable live trading?", icon="warning"):
                self.v_mode.set("paper")
                return
        cfg["mode"] = new_mode
        self.store.save_settings(cfg)
        self.engine.commands.put(("reload",))
        self._log_line("info", "Settings saved and applied.")

    def _save_keys(self):
        name = self.key_name.get().strip()
        secret = self.key_secret.get("1.0", "end").strip()
        if not name or not secret:
            messagebox.showerror("Missing", "Paste both the key name and the "
                                            "private key first.")
            return
        self.store.set("cb_key_name", secure.protect(name))
        self.store.set("cb_private_key", secure.protect(secret))
        self.key_name.delete(0, "end")
        self.key_secret.delete("1.0", "end")
        self.store.log("info", "API keys updated (stored encrypted)")
        self._update_keys_status()
        messagebox.showinfo("Saved", "Keys encrypted and saved. Use 'Test "
                                     "connection' to verify them.")

    def _delete_keys(self):
        self.store.delete("cb_key_name")
        self.store.delete("cb_private_key")
        self.store.log("info", "API keys deleted")
        self._update_keys_status()

    def _test_keys(self):
        if not self.store.get("cb_key_name"):
            self.keys_status.config(text="No keys saved to test.", fg=WARN)
            return
        self.test_btn.config(state="disabled")
        self.keys_status.config(text="Testing connection…", fg=MUTED)

        def work():
            try:
                from .market import LiveBroker
                broker = LiveBroker(
                    secure.unprotect(self.store.get("cb_key_name")),
                    secure.unprotect(self.store.get("cb_private_key")))
                usd = broker.test()
                msg = (f"✓ Connected to Coinbase — ${usd:,.2f} USD/USDC available "
                       f"for trading.", GOOD)
            except Exception as e:
                msg = (f"✗ Connection failed: {e}", BAD)
            self.after(0, lambda: (self.keys_status.config(text=msg[0], fg=msg[1]),
                                   self.test_btn.config(state="normal")))
        threading.Thread(target=work, daemon=True).start()

    # ---------- event pump ----------
    def _drain_events(self):
        try:
            while True:
                ev = self.events.get_nowait()
                if ev["type"] == "log":
                    self._log_line(ev["level"], ev["msg"], ev["ts"])
                elif ev["type"] == "status":
                    self.status = ev
                    self._apply_status(ev)
        except queue.Empty:
            pass
        self.after(400, self._drain_events)

    def _log_line(self, level, msg, ts=None):
        stamp = datetime.datetime.fromtimestamp(
            ts) if ts else datetime.datetime.now()
        tag = level if level in ("error", "warn", "trade") else "muted"
        self.log_text.config(state="normal")
        self.log_text.insert("end", f"{stamp:%H:%M:%S}  {msg}\n", tag)
        self.log_text.see("end")
        # keep the widget from growing forever
        if int(self.log_text.index("end-1c").split(".")[0]) > 400:
            self.log_text.delete("1.0", "50.0")
        self.log_text.config(state="disabled")

    def _apply_status(self, s):
        mode = s["mode"]
        self.mode_badge.config(text=f" {mode.upper()} ",
                               bg=BLUE if mode == "paper" else BAD)
        state_color = {"running": GOOD, "paused": MUTED, "halted": WARN}
        self.state_lbl.config(text=s["state"], fg=state_color.get(s["state"], MUTED))
        if s["conn"] is True:
            self.conn_dot.itemconfig(self._dot, fill=GOOD)
            self.conn_lbl.config(text="Coinbase data: connected", fg=INK2)
        elif s["conn"] is False:
            self.conn_dot.itemconfig(self._dot, fill=BAD)
            self.conn_lbl.config(text="connection lost — retrying", fg=BAD)

        eq = s["equity"]
        v, sub = self.tile_vals["equity"]
        v.config(text=fmt_money(eq))
        sub.config(text=f"cash {fmt_money(s['cash'])}")

        v, sub = self.tile_vals["day"]
        if s["day_start"]:
            d = eq - s["day_start"]
            pct = d / s["day_start"] * 100 if s["day_start"] else 0
            v.config(text=fmt_money(d, sign=True), fg=GOOD if d >= 0 else BAD)
            sub.config(text=f"{'+' if pct >= 0 else '−'}{abs(pct):.2f}% today")
        else:
            v.config(text="—", fg=INK)

        # the honest benchmark: what would just holding BTC have returned?
        bench_txt = ""
        b_btc = s.get("baseline_btc")
        btc_now = s["prices"].get("BTC-USD")
        if b_btc and btc_now:
            bp = (btc_now / b_btc - 1) * 100
            bench_txt = f" · BTC hold {'+' if bp >= 0 else '−'}{abs(bp):.1f}%"

        v, sub = self.tile_vals["total"]
        base = s.get("baseline") or 0
        if mode == "paper" and base:
            d = eq - base
            pct = d / base * 100
            v.config(text=fmt_money(d, sign=True), fg=GOOD if d >= 0 else BAD)
            sub.config(text=f"bot {'+' if pct >= 0 else '−'}{abs(pct):.1f}%{bench_txt}")
        else:
            st = self.store.trade_stats(mode)
            d = st["total_pnl"]
            v.config(text=fmt_money(d, sign=True), fg=GOOD if d >= 0 else BAD)
            sub.config(text=f"realized{bench_txt}")

        st = self.store.trade_stats(mode)
        v, sub = self.tile_vals["winrate"]
        v.config(text=str(st["closed"]))
        if st["closed"]:
            sub.config(text=f"{st['wins']}/{st['closed']} profitable")
        else:
            sub.config(text="none closed yet")

        v, sub = self.tile_vals["drawdown"]
        series = self.store.equity_series(mode, 600)
        if len(series) >= 2:
            peak, mdd = series[0][1], 0.0
            for _, val in series:
                peak = max(peak, val)
                if peak > 0:
                    mdd = max(mdd, 1 - val / peak)
            v.config(text=f"−{mdd * 100:.1f}%",
                     fg=BAD if mdd > 0.05 else INK)
            sub.config(text="worst peak-to-trough")
        else:
            v.config(text="—", fg=INK)
            sub.config(text="collecting data")

        # prices
        for pair, price in s["prices"].items():
            if pair not in self.price_lbls:
                f = tk.Frame(self.price_row, bg=SURFACE)
                f.pack(side="left", padx=(0, 30))
                tk.Label(f, text=pair.replace("-USD", ""), bg=SURFACE, fg=MUTED,
                         font=(FONT, 8, "bold")).pack(anchor="w")
                lbl = tk.Label(f, text="—", bg=SURFACE, fg=INK,
                               font=(FONT, 13, "bold"))
                lbl.pack(anchor="w")
                self.price_lbls[pair] = lbl
            self.price_lbls[pair].config(
                text=f"${price:,.2f}" if price >= 10 else f"${price:,.4f}")

        # positions table
        self.pos_tree.delete(*self.pos_tree.get_children())
        for pair, p in s["positions"].items():
            price = s["prices"].get(pair, p["entry"])
            unreal = (price - p["entry"]) * p["qty"]
            tag = "up" if unreal >= 0 else "down"
            self.pos_tree.insert("", "end", tags=(tag,), values=(
                pair, f"{p['qty']:.6f}", f"${p['entry']:,.2f}",
                f"${price:,.2f}", f"${p['stop']:,.2f}",
                fmt_money(unreal, sign=True)))
        if not s["positions"]:
            self.pos_tree.insert("", "end", values=("—", "", "", "", "",
                                                    "no open positions"))
        self._draw_chart()

    # ---------- equity chart ----------
    def _draw_chart(self):
        c = self.chart
        c.delete("all")
        w = c.winfo_width()
        h = int(c["height"])
        if w < 60:
            return
        mode = self.status["mode"] if self.status else self.engine.cfg["mode"]
        series = self.store.equity_series(mode, 600)
        if len(series) < 2:
            c.create_text(w // 2, h // 2, text="Collecting equity data…",
                          fill=MUTED, font=(FONT, 9))
            return
        pad_l, pad_r, pad_t, pad_b = 8, 64, 8, 18
        xs0, xs1 = pad_l, w - pad_r
        ys0, ys1 = pad_t, h - pad_b
        vals = [v for _, v in series]
        vmin, vmax = min(vals), max(vals)
        if vmax - vmin < 1e-9:
            vmin -= 1; vmax += 1
        span = vmax - vmin

        for frac in (0.0, 0.5, 1.0):
            y = ys1 - frac * (ys1 - ys0)
            c.create_line(xs0, y, xs1, y, fill=GRID)
            c.create_text(xs1 + 6, y, anchor="w", fill=MUTED, font=(FONT, 8),
                          text=f"${vmin + frac * span:,.0f}")

        n = len(series)
        pts = []
        for i, (_, v) in enumerate(series):
            x = xs0 + (xs1 - xs0) * i / (n - 1)
            y = ys1 - (v - vmin) / span * (ys1 - ys0)
            pts.extend((x, y))
        c.create_line(*pts, fill=BLUE, width=2, smooth=False)
        c.create_oval(pts[-2] - 3, pts[-1] - 3, pts[-2] + 3, pts[-1] + 3,
                      fill=BLUE, outline=SURFACE, width=2)

        t0 = datetime.datetime.fromtimestamp(series[0][0])
        t1 = datetime.datetime.fromtimestamp(series[-1][0])
        c.create_text(xs0, h - 6, anchor="w", fill=MUTED, font=(FONT, 8),
                      text=t0.strftime("%b %d %H:%M"))
        c.create_text(xs1, h - 6, anchor="e", fill=MUTED, font=(FONT, 8),
                      text=t1.strftime("%b %d %H:%M"))

    # ---------- history refresh ----------
    def _refresh_history(self):
        self.trades_tree.delete(*self.trades_tree.get_children())
        for (opened, closed, mode, pair, qty, entry, exit_p, fee, pnl, status,
             r_open, r_close) in self.store.recent_trades():
            tag = ()
            if pnl is not None:
                tag = ("up",) if pnl >= 0 else ("down",)
            self.trades_tree.insert("", "end", tags=tag, values=(
                fmt_ts(opened), fmt_ts(closed), mode, pair,
                f"{qty:.6f}" if qty else "",
                f"${entry:,.2f}" if entry else "",
                f"${exit_p:,.2f}" if exit_p else ("open" if status == "open" else ""),
                f"${fee:,.2f}" if fee else "",
                fmt_money(pnl, sign=True) if pnl is not None else "",
                r_open or "", r_close or ""))
        self.actions_tree.delete(*self.actions_tree.get_children())
        for ts, level, msg in self.store.recent_actions():
            tag = (level,) if level in ("error", "warn", "trade") else ()
            self.actions_tree.insert("", "end", tags=tag,
                                     values=(fmt_ts(ts), level, msg))

    def _history_loop(self):
        self._refresh_history()
        self.after(30000, self._history_loop)

    def _on_close(self):
        self.engine.shutdown()
        self.destroy()


def main():
    App().mainloop()


if __name__ == "__main__":
    main()
