"""Backtester: replays the exact live strategy rules over historical candles.

Mirrors the engine's logic — EMA cross entries, ATR trailing stops, risk-based
sizing, daily loss halt, fees and slippage — and compares the result against
simply buying and holding the same coins ("the honest benchmark").

Execution model (approximations, deliberately conservative):
  * signals are computed on closed candles; fills happen at that candle's close
  * stop-losses trigger intra-candle on the candle's low; if the candle *opened*
    below the stop (a gap), the fill is the open, not the stop
  * entries and trend exits pay the maker fee when prefer_maker is on;
    stop-outs and halts always pay the taker fee (they're urgent market sells)
"""

import datetime

from .engine import ema_series


def ema_aligned(values, period):
    """EMA aligned to values' indices (None before warm-up)."""
    out = [None] * len(values)
    s = ema_series(values, period)
    if s:
        out[period - 1:] = s
    return out


def atr_aligned(candles, period):
    out = [None] * len(candles)
    a = None
    trs = []
    for i in range(1, len(candles)):
        _, lo, hi, op, cl, _ = candles[i]
        prev_close = candles[i - 1][4]
        tr = max(hi - lo, abs(hi - prev_close), abs(lo - prev_close))
        if a is None:
            trs.append(tr)
            if len(trs) == period:
                a = sum(trs) / period
                out[i] = a
        else:
            a = (a * (period - 1) + tr) / period
            out[i] = a
    return out


def run_backtest(store, cfg, pairs, start_ts, end_ts, start_cash,
                 trend_filter=True, prefer_maker=True, progress=None):
    from . import history
    gran = cfg["granularity"]

    data = {}
    for pi, pair in enumerate(pairs):
        def prog(frac, msg, _pi=pi):
            if progress:
                progress((_pi + frac) / len(pairs) * 0.5, msg)
        candles = history.get_history(store, pair, gran, start_ts, end_ts, prog)
        if len(candles) < cfg["ema_slow"] + 10:
            raise ValueError(f"Not enough history for {pair}")
        data[pair] = {
            "candles": candles,
            "by_ts": {c[0]: i for i, c in enumerate(candles)},
            "ef": ema_aligned([c[4] for c in candles], cfg["ema_fast"]),
            "es": ema_aligned([c[4] for c in candles], cfg["ema_slow"]),
            "e200": ema_aligned([c[4] for c in candles], 200),
            "atr": atr_aligned(candles, cfg["atr_period"]),
        }

    timeline = sorted({c[0] for d in data.values() for c in d["candles"]})
    if not timeline:
        raise ValueError("No candle data in range")

    taker = cfg["fee_rate"]
    maker = cfg["maker_fee"] if prefer_maker else cfg["fee_rate"]
    slip = cfg["slippage"]

    cash = start_cash
    positions = {}
    trades = []
    curve = []
    day = None
    day_start = None
    halted = False
    last_price = {}

    def equity():
        return cash + sum(p["qty"] * last_price.get(pr, p["entry"])
                          for pr, p in positions.items())

    def close_pos(pair, fill, fee_rate, reason, ts):
        nonlocal cash
        pos = positions.pop(pair)
        fill *= (1 - slip)
        proceeds = pos["qty"] * fill
        fee = proceeds * fee_rate
        cash += proceeds - fee
        pnl = proceeds - fee - pos["cost"]
        trades.append({"pair": pair, "entry": pos["entry"], "exit": fill,
                       "qty": pos["qty"], "pnl": pnl,
                       "fees": pos["fee_in"] + fee,
                       "opened": pos["opened"], "closed": ts, "reason": reason})

    for n, ts in enumerate(timeline):
        if progress and n % 500 == 0:
            progress(0.5 + n / len(timeline) * 0.5, "simulating…")

        d0 = datetime.date.fromtimestamp(ts)
        if day != d0:
            day = d0
            day_start = equity()
            halted = False

        for pair in pairs:
            i = data[pair]["by_ts"].get(ts)
            if i is None or i < 1:
                continue
            dd = data[pair]
            c = dd["candles"][i]
            _, lo, hi, op, cl, _ = c
            last_price[pair] = cl
            ef, es, atr = dd["ef"][i], dd["es"][i], dd["atr"][i]
            ef1, es1 = dd["ef"][i - 1], dd["es"][i - 1]
            if ef is None or es is None or ef1 is None or es1 is None or not atr:
                continue

            pos = positions.get(pair)
            if pos:
                # 1) intra-candle stop check
                if lo <= pos["stop"]:
                    fill = op if op < pos["stop"] else pos["stop"]
                    close_pos(pair, fill, taker, "stop", ts)
                    continue
                # 2) trail the stop on the close
                new_stop = cl - cfg["trail_atr"] * atr
                if new_stop > pos["stop"]:
                    pos["stop"] = new_stop
                # 3) trend exit on the close
                if ef < es and ef1 >= es1:
                    close_pos(pair, cl, maker, "trend exit", ts)
            elif not halted and ef > es and ef1 <= es1:
                if trend_filter and (dd["e200"][i] is None or cl <= dd["e200"][i]):
                    continue
                eq = equity()
                risk_amt = eq * cfg["risk_per_trade"]
                stop_dist = cfg["stop_atr"] * atr
                if stop_dist <= 0:
                    continue
                qty = risk_amt / stop_dist
                notional = qty * cl
                cap = min(cfg["max_pos_frac"] * eq, cash / (1 + maker) * 0.995)
                if notional > cap:
                    notional = cap
                    qty = notional / cl
                if notional < cfg["min_notional"]:
                    continue
                fill = cl * (1 + slip)
                cost = qty * fill
                fee = cost * maker
                cash -= cost + fee
                positions[pair] = {"qty": qty, "entry": fill, "cost": cost + fee,
                                   "fee_in": fee, "opened": ts,
                                   "stop": fill - cfg["stop_atr"] * atr}

        eq = equity()
        if not halted and day_start and eq <= day_start * (1 - cfg["daily_halt"]):
            halted = True
            for pair in list(positions):
                close_pos(pair, last_price[pair], taker, "daily halt", ts)
            eq = equity()
        curve.append((ts, eq))

    # close anything still open at the end so results are fully realized
    for pair in list(positions):
        close_pos(pair, last_price[pair], maker, "end of test", timeline[-1])
    curve[-1] = (timeline[-1], equity())

    # buy & hold benchmark: split start_cash across pairs at first close
    bench = []
    qty0 = {}
    for pair in pairs:
        first_close = data[pair]["candles"][0][4]
        alloc = start_cash / len(pairs)
        qty0[pair] = alloc * (1 - taker) / first_close
    for ts in timeline:
        v = 0.0
        for pair in pairs:
            i = data[pair]["by_ts"].get(ts)
            if i is not None:
                last_price[pair] = data[pair]["candles"][i][4]
            v += qty0[pair] * last_price.get(pair, 0)
        bench.append((ts, v))

    return {
        "curve": curve, "bench": bench, "trades": trades,
        "strategy": summarize(curve, trades, start_cash),
        "buyhold": summarize(bench, [], start_cash),
        "pairs": pairs,
        "start": timeline[0], "end": timeline[-1],
    }


def summarize(curve, trades, start_cash):
    vals = [v for _, v in curve]
    final = vals[-1]
    total_ret = final / start_cash - 1
    years = max((curve[-1][0] - curve[0][0]) / (365.25 * 86400), 1e-6)
    cagr = (final / start_cash) ** (1 / years) - 1 if final > 0 else -1.0

    peak = vals[0]
    max_dd = 0.0
    for v in vals:
        peak = max(peak, v)
        max_dd = max(max_dd, 1 - v / peak)

    half = len(vals) // 2
    first_half = vals[half] / vals[0] - 1 if half else 0.0
    second_half = vals[-1] / vals[half] - 1 if half else 0.0

    wins = [t["pnl"] for t in trades if t["pnl"] > 0]
    losses = [t["pnl"] for t in trades if t["pnl"] <= 0]
    out = {
        "final": final, "total_return": total_ret, "cagr": cagr,
        "max_dd": max_dd, "first_half": first_half, "second_half": second_half,
        "n_trades": len(trades), "wins": len(wins),
        "win_rate": len(wins) / len(trades) if trades else 0.0,
        "avg_win": sum(wins) / len(wins) if wins else 0.0,
        "avg_loss": sum(losses) / len(losses) if losses else 0.0,
        "profit_factor": (sum(wins) / abs(sum(losses))
                          if losses and sum(losses) < 0 else float("inf") if wins else 0.0),
        "fees": sum(t["fees"] for t in trades),
    }
    return out
