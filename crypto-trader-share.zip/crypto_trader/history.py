"""Historical candle downloader with a local cache.

Coinbase's public candle endpoint returns at most 300 candles per request, so
long ranges are fetched in chunks (politely rate-limited) and cached in the
local database — the first backtest over a range is slow-ish, repeats are
instant.
"""

import datetime
import json
import time
import urllib.parse
import urllib.request

BASE = "https://api.exchange.coinbase.com"
_HEADERS = {"User-Agent": "CryptoTraderLocal/1.0"}
CHUNK = 300  # candles per request (API max)


def _iso(ts):
    return datetime.datetime.utcfromtimestamp(ts).strftime("%Y-%m-%dT%H:%M:%SZ")


def _fetch_chunk(pair, gran, start_ts, end_ts):
    q = urllib.parse.urlencode(
        {"granularity": gran, "start": _iso(start_ts), "end": _iso(end_ts)})
    url = f"{BASE}/products/{urllib.parse.quote(pair)}/candles?{q}"
    req = urllib.request.Request(url, headers=_HEADERS)
    for attempt in range(3):
        try:
            with urllib.request.urlopen(req, timeout=20) as r:
                return json.loads(r.read().decode("utf-8"))
        except Exception:
            if attempt == 2:
                raise
            time.sleep(1.5 * (attempt + 1))


def get_history(store, pair, gran, start_ts, end_ts, progress=None):
    """Candles for [start_ts, end_ts) oldest-first: [ts, low, high, open, close, vol].

    Serves from cache when it looks complete; otherwise downloads and caches.
    progress: optional callback(fraction_done, message).
    """
    start_ts = int(start_ts // gran * gran)
    end_ts = int(end_ts // gran * gran)
    expected = (end_ts - start_ts) // gran
    have = store.cached_candle_count(pair, gran, start_ts, end_ts)
    # exchanges have occasional gap candles; 97% counts as complete
    if expected > 0 and have >= expected * 0.97:
        return store.get_candles(pair, gran, start_ts, end_ts)

    n_chunks = max(1, (expected + CHUNK - 1) // CHUNK)
    done = 0
    s = start_ts
    while s < end_ts:
        e = min(s + CHUNK * gran, end_ts)
        rows = _fetch_chunk(pair, gran, s, e)
        if rows:
            store.save_candles(pair, gran, rows)
        done += 1
        if progress:
            progress(done / n_chunks, f"{pair}: downloading history "
                                      f"({done}/{n_chunks} chunks)")
        time.sleep(0.15)  # stay well under public rate limits
        s = e
    return store.get_candles(pair, gran, start_ts, end_ts)
