"""Cross-platform secret encryption for API keys.

Windows: DPAPI (tied to the Windows user account) — see winsecure.py.
Linux/Pi: Fernet (AES) with a random key file stored next to the database,
readable only by the owning user (chmod 600). Anyone who can read that file
can read the keys, so protect the Pi user account — same threat model as
DPAPI on an unlocked PC.
"""

import sys

if sys.platform == "win32":
    from .winsecure import protect, unprotect  # noqa: F401
else:
    import os

    _KEY_PATH = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "secret.key")

    def _fernet():
        from cryptography.fernet import Fernet
        if not os.path.exists(_KEY_PATH):
            key = Fernet.generate_key()
            fd = os.open(_KEY_PATH, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            try:
                os.write(fd, key)
            finally:
                os.close(fd)
        with open(_KEY_PATH, "rb") as f:
            return Fernet(f.read())

    def protect(plaintext: str) -> str:
        return _fernet().encrypt(plaintext.encode("utf-8")).decode("ascii")

    def unprotect(token: str) -> str:
        return _fernet().decrypt(token.encode("ascii")).decode("utf-8")
