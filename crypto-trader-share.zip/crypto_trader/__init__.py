"""Crypto Trader — local automated trading app (paper & live) for Coinbase Advanced."""

__version__ = "1.0.0"
