"""Web dashboard server — the headless (Raspberry Pi) replacement for the
tkinter GUI. Serves a single-page app plus a small JSON API on the local
network; the trading engine keeps running regardless of any browser.

Security model: LAN-only convenience server. Set web_password in Settings to
require HTTP Basic auth. Never port-forward this to the internet.
"""

import base64
import json
import os
import threading
import time
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from . import backtest
from . import notify
from . import secure
from .market import LiveBroker

_WEB_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "web")


class ServerState:
    """Shared state between the engine's event stream and HTTP requests."""

    def __init__(self, store, engine):
        self.store = store
        self.engine = engine
        self.status = {}
        self.logs = deque(maxlen=400)
        self.bt = {"running": False, "progress": 0.0, "message": "",
                   "result": None, "error": None}
        threading.Thread(target=self._drain, daemon=True).start()

    def _drain(self):
        while True:
            ev = self.engine.events.get()
            if ev["type"] == "status":
                self.status = ev
            elif ev["type"] == "log":
                self.logs.append(ev)

    # ---- backtest ----
    def start_backtest(self, years, cash, trend_filter, prefer_maker):
        if self.bt["running"]:
            return False
        self.bt.update(running=True, progress=0.0, message="starting…",
                       result=None, error=None)

        def prog(f, m):
            self.bt["progress"] = f
            self.bt["message"] = m

        def work():
            try:
                cfg = self.store.load_settings()
                end = time.time()
                start = end - years * 365.25 * 86400
                res = backtest.run_backtest(
                    self.store, cfg, cfg["pairs"], start, end, cash,
                    trend_filter=trend_filter, prefer_maker=prefer_maker,
                    progress=prog)
                self.bt["result"] = {
                    "strategy": res["strategy"], "buyhold": res["buyhold"],
                    "curve": _downsample(res["curve"]),
                    "bench": _downsample(res["bench"]),
                    "pairs": res["pairs"],
                }
            except Exception as e:
                self.bt["error"] = str(e)
            finally:
                self.bt["running"] = False
                self.bt["message"] = "done"
        threading.Thread(target=work, daemon=True).start()
        return True


def _downsample(series, cap=900):
    step = max(1, len(series) // cap)
    out = series[::step]
    if out[-1] != series[-1]:
        out.append(series[-1])
    return out


class Handler(BaseHTTPRequestHandler):
    state: ServerState = None  # injected by serve()

    # ---- plumbing ----
    def log_message(self, fmt, *args):
        pass  # keep journald clean; the app has its own action log

    def _send(self, code, body, ctype="application/json"):
        data = body if isinstance(body, bytes) else json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _json(self, code, obj):
        try:
            data = json.dumps(obj).encode()
        except (TypeError, ValueError):
            data = json.dumps(obj, default=lambda o: None).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if not n:
            return {}
        try:
            return json.loads(self.rfile.read(n).decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            return {}

    def _authed(self):
        pw = (self.state.store.load_settings().get("web_password") or "").strip()
        if not pw:
            return True
        hdr = self.headers.get("Authorization") or ""
        if hdr.startswith("Basic "):
            try:
                creds = base64.b64decode(hdr[6:]).decode("utf-8")
                return creds.split(":", 1)[-1] == pw
            except Exception:
                return False
        return False

    def _deny(self):
        self.send_response(401)
        self.send_header("WWW-Authenticate", 'Basic realm="Crypto Trader"')
        self.send_header("Content-Length", "0")
        self.end_headers()

    # ---- routing ----
    def do_GET(self):
        if not self._authed():
            return self._deny()
        st = self.state
        path = self.path.split("?")[0]
        if path in ("/", "/index.html"):
            with open(os.path.join(_WEB_DIR, "index.html"), "rb") as f:
                return self._send(200, f.read(), "text/html; charset=utf-8")
        if path == "/api/status":
            store = st.store
            mode = st.status.get("mode") or store.load_settings()["mode"]
            series = store.equity_series(mode, 600)
            return self._json(200, {
                "status": st.status,
                "logs": list(st.logs)[-150:],
                "stats": store.trade_stats(mode),
                "equity_series": _downsample(series) if series else [],
            })
        if path == "/api/history":
            store = st.store
            trades = [dict(zip(
                ("opened", "closed", "mode", "pair", "qty", "entry", "exit",
                 "fee", "pnl", "status", "reason_open", "reason_close"), r))
                for r in store.recent_trades()]
            actions = [{"ts": a[0], "level": a[1], "msg": a[2]}
                       for a in store.recent_actions()]
            return self._json(200, {"trades": trades, "actions": actions})
        if path == "/api/settings":
            cfg = st.store.load_settings()
            cfg["web_password_set"] = bool((cfg.get("web_password") or "").strip())
            cfg.pop("web_password", None)
            return self._json(200, cfg)
        if path == "/api/keys":
            return self._json(200, {"saved": bool(st.store.get("cb_key_name"))})
        if path == "/api/backtest":
            bt = dict(self.state.bt)
            if bt.get("result"):
                r = dict(bt["result"])
                for side in ("strategy", "buyhold"):
                    r[side] = {k: (None if isinstance(v, float)
                                   and (v == float("inf") or v != v) else v)
                               for k, v in r[side].items()}
                bt["result"] = r
            return self._json(200, bt)
        self._json(404, {"error": "not found"})

    def do_POST(self):
        if not self._authed():
            return self._deny()
        st = self.state
        path = self.path.split("?")[0]
        body = self._body()

        if path == "/api/command":
            cmd = body.get("cmd")
            if cmd not in ("start", "pause", "flatten", "reset_paper",
                           "reload", "test_notify"):
                return self._json(400, {"error": "unknown command"})
            if cmd == "start":
                cfg = st.store.load_settings()
                if cfg["mode"] == "live" and not st.store.get("cb_key_name"):
                    return self._json(400, {"error": "Live mode needs API keys "
                                                     "— add them first."})
            st.engine.commands.put((cmd,))
            return self._json(200, {"ok": True})

        if path == "/api/settings":
            return self._save_settings(body)

        if path == "/api/keys":
            name = (body.get("name") or "").strip()
            sec = (body.get("secret") or "").strip()
            if not name or not sec:
                return self._json(400, {"error": "both fields required"})
            st.store.set("cb_key_name", secure.protect(name))
            st.store.set("cb_private_key", secure.protect(sec))
            st.store.log("info", "API keys updated (stored encrypted)")
            return self._json(200, {"ok": True})

        if path == "/api/keys/delete":
            st.store.delete("cb_key_name")
            st.store.delete("cb_private_key")
            st.store.log("info", "API keys deleted")
            return self._json(200, {"ok": True})

        if path == "/api/keys/test":
            key = st.store.get("cb_key_name")
            sec = st.store.get("cb_private_key")
            if not key:
                return self._json(400, {"error": "no keys saved"})
            try:
                broker = LiveBroker(secure.unprotect(key), secure.unprotect(sec))
                usd = broker.test()
                return self._json(200, {"ok": True, "usd": usd})
            except Exception as e:
                return self._json(200, {"ok": False, "error": str(e)})

        if path == "/api/notify/test":
            cfg = {"ntfy_topic": body.get("ntfy_topic", ""),
                   "telegram_token": body.get("telegram_token", ""),
                   "telegram_chat": body.get("telegram_chat", "")}
            if not notify.configured(cfg):
                return self._json(400, {"error": "nothing configured"})
            notify.send_async(cfg, "Crypto Trader",
                              "Test notification — you're connected! 🎉")
            return self._json(200, {"ok": True})

        if path == "/api/backtest":
            try:
                years = min(6.0, max(0.1, float(body.get("years", 2))))
                cash = max(10.0, float(body.get("cash", 1000)))
            except (TypeError, ValueError):
                return self._json(400, {"error": "years and cash must be numbers"})
            ok = st.start_backtest(
                years, cash, bool(body.get("trend_filter", True)),
                bool(body.get("prefer_maker", True)))
            return self._json(200 if ok else 409,
                              {"ok": ok} if ok else {"error": "already running"})

        self._json(404, {"error": "not found"})

    # ---- settings validation (mirrors the desktop app) ----
    def _save_settings(self, body):
        st = self.state
        cfg = st.store.load_settings()
        try:
            def num(key, lo, hi, scale=1.0):
                if key in body:
                    cfg[key] = max(lo, min(hi, float(body[key]) * scale))
            num("risk_per_trade", 0.001, 0.05)
            num("daily_halt", 0.01, 0.5)
            num("max_pos_frac", 0.05, 1.0)
            num("stop_atr", 0.5, 20.0)
            num("trail_atr", 0.5, 20.0)
            num("fee_rate", 0.0, 0.05)
            num("maker_fee", 0.0, 0.05)
            num("paper_start_cash", 10.0, 1e9)
            if "poll_seconds" in body:
                cfg["poll_seconds"] = max(15, int(float(body["poll_seconds"])))
            if "granularity" in body:
                g = int(body["granularity"])
                if g in (3600, 21600, 86400):
                    cfg["granularity"] = g
        except (TypeError, ValueError):
            return self._json(400, {"error": "a setting isn't a valid number"})

        if "pairs" in body:
            pairs = [p for p in body["pairs"] if isinstance(p, str)
                     and p.endswith("-USD")]
            if not pairs:
                return self._json(400, {"error": "select at least one coin"})
            cfg["pairs"] = pairs
        for key in ("trend_filter", "prefer_maker"):
            if key in body:
                cfg[key] = bool(body[key])
        for key in ("ntfy_topic", "telegram_token", "telegram_chat"):
            if key in body:
                cfg[key] = str(body[key]).strip()
        if "web_password" in body:  # empty string clears it
            cfg["web_password"] = str(body["web_password"]).strip()
        if "web_port" in body:
            try:
                cfg["web_port"] = max(1024, min(65535, int(body["web_port"])))
            except (TypeError, ValueError):
                pass

        new_mode = body.get("mode")
        if new_mode in ("paper", "live") and new_mode != cfg["mode"]:
            if new_mode == "live":
                if not st.store.get("cb_key_name"):
                    return self._json(400, {"error": "Add API keys before "
                                                     "enabling live trading."})
                if st.engine.positions:
                    return self._json(400, {"error": "Close open positions "
                                                     "before switching to live."})
            cfg["mode"] = new_mode
        st.store.save_settings(cfg)
        st.engine.commands.put(("reload",))
        return self._json(200, {"ok": True})


def serve(store, engine, port=None):
    """Blocking; runs the dashboard until the process exits."""
    state = ServerState(store, engine)
    Handler.state = state
    port = port or int(store.load_settings().get("web_port") or 8080)
    httpd = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    store.log("info", f"Web dashboard listening on port {port}")
    httpd.serve_forever()
