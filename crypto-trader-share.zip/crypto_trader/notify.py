"""Phone/desktop push notifications via ntfy.sh and/or Telegram (both optional).

ntfy.sh needs zero signup: pick a unique topic name in Settings, install the
ntfy app on your phone, and subscribe to the same topic.
"""

import json
import threading
import urllib.parse
import urllib.request


def configured(cfg):
    return bool(cfg.get("ntfy_topic")
                or (cfg.get("telegram_token") and cfg.get("telegram_chat")))


def send_async(cfg, title, message):
    if not configured(cfg):
        return
    threading.Thread(target=_send, args=(dict(cfg), title, message),
                     daemon=True).start()


def _send(cfg, title, message):
    topic = (cfg.get("ntfy_topic") or "").strip()
    if topic:
        try:
            req = urllib.request.Request(
                f"https://ntfy.sh/{urllib.parse.quote(topic)}",
                data=message.encode("utf-8"),
                headers={"Title": title, "User-Agent": "CryptoTraderLocal/1.0"})
            urllib.request.urlopen(req, timeout=10).read()
        except Exception:
            pass
    token = (cfg.get("telegram_token") or "").strip()
    chat = (cfg.get("telegram_chat") or "").strip()
    if token and chat:
        try:
            q = urllib.parse.urlencode({"chat_id": chat,
                                        "text": f"{title}\n{message}"})
            urllib.request.urlopen(
                f"https://api.telegram.org/bot{token}/sendMessage?{q}",
                timeout=10).read()
        except Exception:
            pass
