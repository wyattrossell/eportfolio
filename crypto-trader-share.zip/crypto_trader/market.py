"""Market data (Coinbase public endpoints, no keys needed) and live order broker."""

import json
import time
import urllib.parse
import urllib.request

BASE = "https://api.exchange.coinbase.com"
_HEADERS = {"User-Agent": "CryptoTraderLocal/1.0"}


def _get(path, timeout=15):
    req = urllib.request.Request(BASE + path, headers=_HEADERS)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def get_price(product):
    """Latest spot price for e.g. 'BTC-USD'."""
    return float(_get(f"/products/{urllib.parse.quote(product)}/ticker")["price"])


def get_closed_candles(product, granularity=3600):
    """Fully closed candles, oldest first. Each: [time, low, high, open, close, volume]."""
    raw = _get(f"/products/{urllib.parse.quote(product)}/candles?granularity={granularity}")
    raw.sort(key=lambda c: c[0])
    now = time.time()
    return [c for c in raw if c[0] + granularity <= now]


class LiveBroker:
    """Real orders on Coinbase Advanced via ccxt. Only used in live mode."""

    def __init__(self, api_key, api_secret):
        import ccxt  # lazy: only needed for live trading
        self.x = ccxt.coinbase({
            "apiKey": api_key,
            "secret": api_secret,
            "enableRateLimit": True,
        })

    @staticmethod
    def _symbol(product):
        return product.replace("-", "/")

    def test(self):
        """Verify credentials; returns available USD/USDC cash."""
        return self.usd_balance()

    def usd_balance(self):
        bal = self.x.fetch_balance()
        free = bal.get("free", {}) or {}
        return float(free.get("USD", 0) or 0) + float(free.get("USDC", 0) or 0)

    def market_buy_cost(self, product, usd_cost):
        """Market-buy spending usd_cost dollars. Returns order id."""
        order = self.x.create_market_buy_order_with_cost(self._symbol(product), usd_cost)
        return order.get("id", "?")

    def market_sell(self, product, qty):
        order = self.x.create_market_sell_order(self._symbol(product), qty)
        return order.get("id", "?")

    # ---- maker (limit) orders: roughly half the fees of market orders ----
    def limit_buy_post_only(self, product, qty, price):
        """Post-only limit buy — guaranteed maker fee or it doesn't fill."""
        order = self.x.create_order(self._symbol(product), "limit", "buy",
                                    qty, price, {"postOnly": True})
        return order.get("id", "?")

    def order_filled(self, order_id, product):
        """Returns (is_fully_filled, average_fill_price_or_None)."""
        o = self.x.fetch_order(order_id, self._symbol(product))
        status = (o.get("status") or "").lower()
        return status == "closed", o.get("average") or o.get("price")

    def cancel_safe(self, order_id, product):
        try:
            self.x.cancel_order(order_id, self._symbol(product))
            return True
        except Exception:
            return False  # may have just filled — caller re-checks

    # ---- exchange-side stop: protection that survives this PC being off ----
    def place_stop_sell(self, product, qty, stop_price):
        """Stop-limit sell resting on Coinbase itself. Returns order id."""
        limit_price = round(stop_price * 0.995, 2)  # small buffer so it fills
        order = self.x.create_order(
            self._symbol(product), "limit", "sell", qty, limit_price,
            {"triggerPrice": stop_price, "stopLossPrice": stop_price})
        return order.get("id", "?")
