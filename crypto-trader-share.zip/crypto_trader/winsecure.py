"""Encrypt/decrypt secrets with Windows DPAPI (tied to this Windows user account).

Keys encrypted here can only be decrypted by the same Windows user on the same
machine, so API keys are never stored in plain text on disk.
"""

import base64
import ctypes
import ctypes.wintypes as wt


class _DATA_BLOB(ctypes.Structure):
    _fields_ = [("cbData", wt.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]


_crypt32 = ctypes.windll.crypt32
_kernel32 = ctypes.windll.kernel32

_ENTROPY = b"crypto-trader-local-v1"


def _blob_in(data: bytes) -> _DATA_BLOB:
    buf = ctypes.create_string_buffer(data, len(data))
    return _DATA_BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char)))


def _blob_out_to_bytes(blob: _DATA_BLOB) -> bytes:
    try:
        return ctypes.string_at(blob.pbData, blob.cbData)
    finally:
        _kernel32.LocalFree(blob.pbData)


def protect(plaintext: str) -> str:
    """Encrypt a string; returns base64 token safe to store on disk."""
    data_in = _blob_in(plaintext.encode("utf-8"))
    entropy = _blob_in(_ENTROPY)
    data_out = _DATA_BLOB()
    ok = _crypt32.CryptProtectData(
        ctypes.byref(data_in), None, ctypes.byref(entropy), None, None, 0,
        ctypes.byref(data_out))
    if not ok:
        raise OSError("DPAPI CryptProtectData failed")
    return base64.b64encode(_blob_out_to_bytes(data_out)).decode("ascii")


def unprotect(token: str) -> str:
    """Decrypt a token produced by protect()."""
    raw = base64.b64decode(token.encode("ascii"))
    data_in = _blob_in(raw)
    entropy = _blob_in(_ENTROPY)
    data_out = _DATA_BLOB()
    ok = _crypt32.CryptUnprotectData(
        ctypes.byref(data_in), None, ctypes.byref(entropy), None, None, 0,
        ctypes.byref(data_out))
    if not ok:
        raise OSError("DPAPI CryptUnprotectData failed (wrong user/machine?)")
    return _blob_out_to_bytes(data_out).decode("utf-8")
