# Crypto Trader — How It Works

An automated trend-following trading bot for Coinbase with a web dashboard,
paper trading, and strict risk controls. Everything runs locally; API keys are
stored encrypted and never leave the machine.

## Architecture

```
run_server.py  (headless entry point — Raspberry Pi / server)
   │
   ├── crypto_trader/engine.py    the trading engine (background thread)
   │      ├── market.py           Coinbase market data + live order broker (ccxt)
   │      ├── store.py            SQLite persistence (trader.db) + trading_history.txt
   │      └── notify.py           phone notifications (ntfy.sh / Telegram)
   │
   └── crypto_trader/webapp.py    web dashboard + JSON API (port 8080)
          └── web/index.html      single-page dashboard UI

run_trader.pyw (Windows entry point — tkinter GUI via crypto_trader/app.py)
```

- **Engine** — a daemon thread that wakes every `poll_seconds` (default 60s),
  fetches candles for each configured pair, evaluates the strategy, and places
  orders (paper-simulated, or real via ccxt in live mode).
- **Web app** — a small threaded HTTP server that serves the dashboard and a
  JSON API. The engine keeps trading regardless of any browser being open.
- **Store** — all state lives in `trader.db` (SQLite, WAL mode): settings,
  trades, action log, equity history, candle cache, and encrypted API keys.
- Engine → webapp communication is a one-way event queue (status + log
  events); webapp → engine is a command queue (start/pause/flatten/...).

## The strategy (exact rules)

Evaluated per pair, on closed candles of the configured granularity:

1. **Entry** — when the fast EMA crosses above the slow EMA
   (`ema_fast`/`ema_slow`, default 20/50) **and**, if the trend filter is on,
   price is above the 200-period EMA (skips choppy/falling regimes).
2. **Position size** — `equity × risk_per_trade ÷ (stop_atr × ATR)`, capped at
   `max_pos_frac` of equity and at available cash. Trades smaller than
   `min_notional` ($10) are skipped (fees would eat them).
3. **Initial stop** — `stop_atr` ATRs below entry (default 2). In live mode a
   stop-limit order is also parked **on Coinbase itself**, so the position is
   protected even if this machine dies.
4. **Trailing** — the stop ratchets up to `trail_atr` ATRs below the highest
   price seen (default 3); it never moves down.
5. **Exit** — stop hit (urgent, market order) or EMA cross back down
   (calm, maker order when `prefer_maker` is on).
6. **Circuit breaker** — if equity drops `daily_halt` (default 5–8%) below the
   day's starting equity, everything is sold and trading halts until the next
   day.

## Tick health & validation

Every poll cycle ("tick") is validated: after a successful tick the engine
checks that every configured pair returned a positive price and records the
time. Successes are surfaced without flooding the log:

- header shows **"Coinbase data: connected · last check HH:MM:SS"** live;
- a green **"Tick OK — recovered after N failed attempt(s)"** line after any
  failure streak ends;
- a green hourly **"Tick health: X/Y checks succeeded"** summary;
- a warning if a tick completes but some pair had no fresh price.

Failed ticks log an error and are retried on the next cycle — a missed tick
can delay a signal by one poll interval but never corrupts state.

## Trading history file

Every **closed** trade is appended as a tab-separated line to
`trading_history.txt`, next to `trader.db`. Columns:

```
opened_epoch  closed_epoch  opened_local  closed_local  mode  pair
qty  entry  exit  fee  pnl  reason_open  reason_close
```

At startup the bot reads this file and **imports any trades missing from the
database** (deduplicated by mode + pair + open time), then rewrites the file
canonically. Practical effects:

- trade history survives database loss or resets;
- the file is human-readable and safe to copy/share/archive;
- "Reset paper account" purges paper trades from both DB and file.

## Files on disk

| File | Purpose |
|---|---|
| `trader.db` (+`-wal`/`-shm`) | SQLite database — all state |
| `trading_history.txt` | human-readable closed-trade log (auto-synced) |
| `secret.key` | encryption key for stored API keys (Linux) |
| `run_server.py` | headless entry point (systemd service on the Pi) |
| `run_trader.pyw` | Windows GUI entry point |
| `deploy/install_pi.sh` | one-shot Raspberry Pi installer (venv + systemd) |

## Further reading

- [SETUP.md](SETUP.md) — installation and first run
- [SETTINGS.md](SETTINGS.md) — every setting explained
- [API.md](API.md) — the dashboard's JSON API
