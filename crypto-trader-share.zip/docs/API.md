# JSON API Reference

The web dashboard is a thin client over this API — anything the UI does, you
can script. Base URL: `http://<machine-ip>:<port>` (default port 8080).

**Auth:** none by default. If a dashboard password is set in Settings, every
route requires HTTP Basic auth (any username, that password):
`curl -u x:PASSWORD ...`. The server is LAN-only by design — never expose it
to the internet.

All responses are JSON. Errors use HTTP status + `{"error": "message"}`.

---

## GET /api/status

Live snapshot: engine state, prices, positions, stats, equity curve.
The dashboard polls this every couple of seconds.

```json
{
  "status": {
    "state": "running",            // "running" | "paused" | "halted"
    "mode": "live",                // "paper" | "live"
    "conn": true,                  // Coinbase reachability (null = unknown yet)
    "last_tick_ok": 1783911600.5,  // epoch of last successful validated tick
    "prices": {"BTC-USD": 61230.1},
    "equity": 194.45, "cash": 194.45,
    "day_start": 194.45,           // equity at start of today (Today's P&L base)
    "baseline": 194.45,            // account baseline (Total P&L base)
    "baseline_btc": 63133.9,       // BTC price at account start (benchmark tile)
    "positions": {"BTC-USD": {"qty": 0.001, "entry": 60000, "stop": 58000}},
    "last_error": ""
  },
  "logs": [ {"ts": 1783911600.5, "level": "ok", "msg": "Tick health: 60/60 …"} ],
  "stats": {"closed": 3, "total_pnl": 12.5, "wins": 2},   // for current mode
  "equity_series": [[1783900000, 194.1], [1783900060, 194.2]]
}
```

Log levels: `info`, `ok` (tick health, green), `warn`, `error`, `trade`.

## GET /api/history

Full trade + action history (the Trading History tab).

```json
{
  "trades": [
    {"opened": 1783900000, "closed": 1783950000, "mode": "live",
     "pair": "BTC-USD", "qty": 0.001, "entry": 60000, "exit": 61000,
     "fee": 0.96, "pnl": 0.04, "status": "closed",
     "reason_open": "EMA20/50 cross up on 6h candles, above EMA200",
     "reason_close": "Trailing stop hit"}
  ],
  "actions": [ {"ts": 1783911600, "level": "info", "msg": "Bot started…"} ]
}
```

Closed trades are also mirrored to `trading_history.txt` on disk (see
OVERVIEW.md) — the API and the file always agree after startup sync.

## GET /api/settings

Current settings (see SETTINGS.md for every key). The stored dashboard
password is never returned — only `"web_password_set": true|false`.

## POST /api/settings

Save any subset of settings; omitted keys keep their values. Numbers are
clamped to their valid ranges; the engine hot-reloads on save.

```bash
curl -X POST http://pi:8080/api/settings \
  -H 'Content-Type: application/json' \
  -d '{"risk_per_trade": 0.02, "daily_halt": 0.08}'
```

Notes:
- fractions, not percent: `0.02` = 2%.
- `granularity` must be 3600, 21600, or 86400.
- `pairs` must be a non-empty list of `"XXX-USD"` strings.
- switching `"mode"` to `"live"` is refused without saved API keys or with
  open positions (`400` + explanatory error).

## POST /api/command

```json
{"cmd": "start"}
```

| cmd | Effect |
|---|---|
| `start` | Begin trading (live mode: connects broker, syncs cash to Coinbase balance). Refused (`400`) in live mode without saved keys. |
| `pause` | Stop opening new trades; existing positions and stops remain tracked. |
| `flatten` | **Emergency stop:** sell all positions at market now, then pause. |
| `reset_paper` | Wipe paper trades/equity, restore `paper_start_cash`. Also purges paper trades from `trading_history.txt`. |
| `reload` | Re-read settings from the DB (POST /api/settings does this for you). |
| `test_notify` | Send a test phone notification. |

## API keys

- **GET /api/keys** → `{"saved": true|false}` (never returns key material)
- **POST /api/keys** `{"name": "organizations/…", "secret": "-----BEGIN EC PRIVATE KEY-----…"}` — stores encrypted
- **POST /api/keys/delete** — removes saved keys
- **POST /api/keys/test** → `{"ok": true, "usd": 194.45}` or `{"ok": false, "error": "…"}` — verifies the key against Coinbase

## Backtesting

- **POST /api/backtest** `{"years": 2, "cash": 1000, "trend_filter": true, "prefer_maker": true}`
  — starts an async backtest of the **current saved settings** over real
  historical candles. `409` if one is already running.
- **GET /api/backtest** — poll progress and result:

```json
{
  "running": false, "progress": 1.0, "message": "done", "error": null,
  "result": {
    "strategy": {"final": 1050.2, "total_return": 0.05, "cagr": 0.025,
                  "max_dd": 0.12, "n_trades": 14, "win_rate": 0.43,
                  "profit_factor": 1.3, "fees": 22.1,
                  "first_half": 0.02, "second_half": 0.03},
    "buyhold": { "same shape": "…" },
    "curve":  [[ts, equity], "…"],
    "bench":  [[ts, equity], "…"],
    "trades": [ {"pair": "…", "pnl": 1.2, "reason": "stop"} ]
  }
}
```

First run downloads candle history (minutes); it's cached in `trader.db`, so
repeats are near-instant.

## POST /api/notify/test

Test notification credentials *without* saving them:
`{"ntfy_topic": "…"}` or `{"telegram_token": "…", "telegram_chat": "…"}`.

## Example: minimal health monitor

```bash
#!/bin/bash
# Alert if the bot's last successful tick is older than 10 minutes
last=$(curl -s http://pi:8080/api/status | python3 -c \
  "import sys,json;print(json.load(sys.stdin)['status'].get('last_tick_ok') or 0)")
age=$(( $(date +%s) - ${last%.*} ))
[ "$age" -gt 600 ] && echo "ALERT: no successful tick for ${age}s"
```
