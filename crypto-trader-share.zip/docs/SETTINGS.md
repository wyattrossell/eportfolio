# Settings Reference

Everything on the dashboard's **Settings** tab, what it does in the engine,
and the accepted range (values outside the range are clamped by the API).
Saving applies immediately — the engine hot-reloads without a restart
(exception: web port).

## Risk

| Setting | Key | Default | Range | What it does |
|---|---|---|---|---|
| Risk per trade (%) | `risk_per_trade` | 1% | 0.1–5% | Fraction of current equity risked on each trade. Position size = `equity × risk ÷ stop distance`, so risk is constant regardless of volatility: a wider stop simply buys less. The single most direct aggressiveness knob. |
| Daily loss halt (%) | `daily_halt` | 5% | 1–50% | If equity falls this far below the day's starting equity, **everything is sold at market and trading halts until tomorrow**. Set it comfortably above `risk_per_trade` or a single stopped-out trade can trip it. |
| Max position (%) | `max_pos_frac` | 50% | 5–100% | Hard cap on any one position as a fraction of equity, applied after risk sizing. Also implicitly caps total exposure across pairs. |
| Initial stop (ATRs) | `stop_atr` | 2.0 | 0.5–20 | Stop-loss distance below entry, in ATR units (ATR = Average True Range, a volatility measure — the stop adapts to how much the coin naturally moves). Smaller = tighter stops, more frequent stop-outs, larger position sizes. |
| Trailing stop (ATRs) | `trail_atr` | 3.0 | 0.5–20 | Once in profit, the stop trails this many ATRs below the highest price seen; it ratchets up, never down. Larger = gives winners more room but returns more profit before exiting. |
| Check every (sec) | `poll_seconds` | 60 | ≥15 | Engine tick interval. Signals only change when a candle closes, so faster polling mainly tightens stop reaction time, at the cost of more API calls. |

## Fees

| Setting | Key | Default | Range | What it does |
|---|---|---|---|---|
| Taker fee (%) | `fee_rate` | 0.8% | 0–5% | Your Coinbase **market-order** fee. Used for urgent exits (stops, halts) and paper simulation. Set this to your real tier or paper results will flatter/punish you falsely. |
| Maker fee (%) | `maker_fee` | 0.4% | 0–5% | Your **limit-order** fee, used when "Prefer maker" is on for entries and calm exits. |
| Paper start cash ($) | `paper_start_cash` | 1000 | ≥10 | Starting balance for paper mode and the amount restored by "Reset paper account". |

**Why fees matter more than any other setting:** a round trip costs
`entry fee + exit fee` (≈0.8–1.6%). A strategy that trades often must clear
that bar *on average every trade*. This is why high-frequency settings that
look exciting get destroyed on small accounts — see the Backtest tab.

## Strategy

| Setting | Key | Default | What it does |
|---|---|---|---|
| EMA200 regime filter | `trend_filter` | on | Only take buy signals while price is above the 200-period EMA. The single biggest protection against chop: in backtests, turning it off multiplied losses several-fold. Leave it on. |
| Prefer maker orders | `prefer_maker` | on | Entries and trend exits use post-only **limit** orders (≈half the fee), waiting `maker_wait_seconds` (45s) for a fill before falling back to market. Urgent exits (stops, halts) always pay taker — protection beats fee savings. |
| Candle size | `granularity` | 6h | 1h / 6h / 1d. Signal timeframe. 6h was chosen by backtest: 1h trades ~10× more often and gets eaten by fees; 1d is very slow. Changing this changes trade frequency more than anything else. |
| Coins | `pairs` | BTC, ETH | Which `-USD` pairs to watch. More pairs = more signal opportunities, but position caps are per-pair, so many simultaneous signals can add up to high total exposure. |

Advanced keys without UI fields (edit via `store.save_settings` / DB only):
`ema_fast`/`ema_slow` (20/50 — the crossover pair), `atr_period` (14),
`maker_wait_seconds` (45), `slippage` (0.05% paper-fill estimate),
`min_notional` ($10 dust-trade floor).

## Trading mode

- **Paper** — fake money, real live prices, no keys needed. Always start here.
- **LIVE** — real orders on Coinbase via ccxt. Requires saved API keys; the
  switch is refused while positions are open. On start, live mode syncs cash
  to your actual Coinbase USD balance.

## Phone notifications (optional)

| Setting | What it does |
|---|---|
| ntfy.sh topic | Install the free ntfy app, subscribe to a topic name, enter it here — the bot pushes every trade, halt, and live-mode error. Topic names are public: pick something unguessable. |
| Telegram bot token + chat id | Alternative channel via a Telegram bot. |

"Send test" fires a test notification through whatever is configured.

## Web dashboard

| Setting | What it does |
|---|---|
| Password | Enables HTTP Basic auth on the dashboard and API (username is ignored; empty clears it). Recommended on shared networks. |
| Port | Dashboard port (default 8080). **Requires a service restart** — the only setting that does. |

## The dashboard tabs

- **Dashboard** — start/pause/emergency-stop, equity + P&L tiles (Total P&L is
  measured against the account baseline), live prices, equity chart, open
  positions, activity feed. Header shows tick health: "connected · last check
  HH:MM:SS".
- **Backtest** — replays your *current* settings over years of real historical
  candles next to a buy-and-hold benchmark. Use it before applying any
  settings change. Distrust results where all profit came from one half of
  the period.
- **Trading History** — every trade (entry, exit, fees, P&L, why
  opened/closed) plus the full action log. Closed trades are also appended to
  `trading_history.txt` next to `trader.db` and re-imported at startup.
- **Settings** — this page.
- **API Keys** — Coinbase key management (encrypted at rest; View + Trade
  permissions only).
