# Setup Guide

## Requirements

- Python 3.10+ with `ccxt` installed (only needed for live trading — paper
  mode uses Coinbase's public market data with no keys at all)
- Network access to `api.coinbase.com` and `api.exchange.coinbase.com`

## Raspberry Pi / Linux server (headless, recommended)

```bash
# one-shot install: creates .venv, installs deps, registers a systemd service
cd "/path/to/AI trading"
bash deploy/install_pi.sh
```

This registers **crypto-trader.service**, which starts the engine + web
dashboard at boot and auto-restarts on crashes. If the bot was running when
the process stopped (power cut, reboot), it resumes trading automatically.

Manage it with:

```bash
sudo systemctl status crypto-trader     # health + recent log
sudo systemctl restart crypto-trader    # restart (bot auto-resumes)
sudo journalctl -u crypto-trader -f     # follow the full log
```

Or run in the foreground without systemd: `.venv/bin/python run_server.py`

The dashboard is at `http://<machine-ip>:8080` (port configurable in
Settings). **LAN-only by design — never port-forward it to the internet.**
Set a dashboard password in Settings if others use your network.

## Windows (desktop GUI)

Double-click `run_trader.pyw` (or the Crypto Trader desktop shortcut). Same
engine, tkinter interface instead of the web dashboard.

## First run (paper mode — no keys needed)

1. Open the dashboard and press **▶ Start**. The badge shows PAPER; the bot
   trades fake money against real live prices.
2. Watch the Dashboard tab: equity tiles, live prices, open positions,
   activity feed. The header shows "Coinbase data: connected · last check
   HH:MM:SS" when ticks are succeeding.
3. Run a **Backtest** to see how your current settings would have performed
   historically before changing anything.

## Going live (real money)

1. Create an API key at <https://portal.cdp.coinbase.com> → API keys with
   **View + Trade permissions ONLY — never Transfer/Withdraw** (so even a
   stolen key cannot drain your account).
2. Dashboard → **API Keys** tab → paste key name + private key → Save →
   **Test connection** (shows your USD balance on success). Keys are stored
   encrypted on this device.
3. Settings → set **Taker/Maker fee** to your actual Coinbase tier (check
   Coinbase → Fees; small accounts are typically ~0.75–1.2% taker).
4. Settings → Trading mode → **LIVE** → Save. Open positions must be closed
   before switching.
5. Press **▶ Start**. Start small; watch the Trading History tab. **Pause**
   stops new trades (positions still tracked); **Sell everything & stop** is
   the emergency exit.

## Updating / moving the bot

Copy the whole folder. Trade history is doubly durable: it lives in
`trader.db` *and* in `trading_history.txt` — if the DB is ever lost, the txt
is re-imported automatically at next startup.

## Troubleshooting

| Symptom | Meaning / fix |
|---|---|
| `Tick failed (will retry): ...unreachable` | one polling cycle couldn't reach Coinbase; harmless if occasional — the next tick retries. Frequent ones: check WiFi power-save, DNS, router. |
| green `Tick OK — recovered after N...` | connectivity came back; nothing to do |
| `Tick health: X/Y checks succeeded` | hourly summary — Y−X ticks failed that hour |
| `Skipped BUY — below $10 minimum` | position sizing produced a dust trade; increase risk % or account size |
| `DAILY LOSS LIMIT hit` | circuit breaker sold everything and halted until tomorrow (by design) |
| Dashboard unreachable | `sudo systemctl status crypto-trader`; check port in Settings; the server binds all interfaces |
