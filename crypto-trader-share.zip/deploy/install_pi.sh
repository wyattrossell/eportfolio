#!/usr/bin/env bash
# Crypto Trader — Raspberry Pi / Debian installer.
# Run from the app directory on the Pi:   bash deploy/install_pi.sh
set -e

APP_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$APP_DIR"
echo "Installing Crypto Trader from $APP_DIR"

sudo apt-get update -qq
sudo apt-get install -y -qq python3-venv

if [ ! -d .venv ]; then
    python3 -m venv .venv
fi
.venv/bin/pip install --quiet --upgrade pip
.venv/bin/pip install --quiet ccxt cryptography

SERVICE=/etc/systemd/system/crypto-trader.service
sudo tee "$SERVICE" >/dev/null <<EOF
[Unit]
Description=Crypto Trader bot + web dashboard
After=network-online.target
Wants=network-online.target

[Service]
User=$USER
WorkingDirectory=$APP_DIR
ExecStart="$APP_DIR/.venv/bin/python" "$APP_DIR/run_server.py"
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable --now crypto-trader

IP=$(hostname -I | awk '{print $1}')
echo
echo "==============================================="
echo "  Crypto Trader is installed and running."
echo "  Dashboard:  http://$IP:8080"
echo "  Status:     sudo systemctl status crypto-trader"
echo "  Logs:       journalctl -u crypto-trader -f"
echo "  Restart:    sudo systemctl restart crypto-trader"
echo "==============================================="
