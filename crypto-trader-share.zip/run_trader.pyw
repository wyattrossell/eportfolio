"""Launcher for Crypto Trader. Double-click (or use the desktop shortcut)."""

import pathlib
import sys
import traceback

ROOT = pathlib.Path(__file__).parent
sys.path.insert(0, str(ROOT))

try:
    from crypto_trader.app import main
    main()
except Exception:
    # pythonw has no console — surface crashes in a log file and a dialog
    err = traceback.format_exc()
    try:
        (ROOT / "error_log.txt").write_text(err, encoding="utf-8")
    except OSError:
        pass
    try:
        import tkinter.messagebox as mb
        import tkinter as tk
        r = tk.Tk(); r.withdraw()
        mb.showerror("Crypto Trader failed to start",
                     f"{err.splitlines()[-1]}\n\nFull details: error_log.txt")
    except Exception:
        pass
    raise
