# Crypto Trader

A local automated crypto trading app for Coinbase, with a dark-themed dashboard,
paper trading, and strict risk controls. Everything runs on your own PC; your
API keys never leave this machine.

**Full documentation** (shareable) lives in [`docs/`](docs/):
[How it works](docs/OVERVIEW.md) · [Setup guide](docs/SETUP.md) ·
[Settings reference](docs/SETTINGS.md) · [JSON API](docs/API.md)

## Honest expectations (read this first)

**No bot can guarantee profits or "never miss" the right time to trade.**
Anyone promising that is scamming you. What this app does instead is what real
trading systems do:

- Follows a **rules-based trend strategy** with positive expected value over
  many trades — individual trades *will* lose; the goal is to win on average.
- Enforces **risk management on every trade**: ~1% of the account risked per
  position, automatic stop-losses, a daily loss circuit-breaker, and an
  emergency sell-everything button.
- Starts in **paper trading mode** — fake money against real live prices — so
  you can watch it work with zero risk before ever committing real funds.

Crypto is volatile. Never trade money you can't afford to lose.

## Starting the app

Double-click the **Crypto Trader** shortcut on your desktop
(or `run_trader.pyw` in this folder). Press **▶ Start** on the Dashboard.
Paper mode needs no API keys — it works immediately.

## The strategy (conservative default, chosen by backtest)

- Watches BTC and ETH on **6-hour candles** — chosen because a 2–3 year
  backtest showed 1-hour signals trade ~10× too often and get eaten by fees,
  while 6-hour candles kept most of the upside with the smallest drawdowns.
- **Buys** when the 20-period EMA crosses above the 50-period EMA (trend
  turning up), but only while price is above the 200-period EMA (regime
  filter — skips choppy/falling markets).
- Sets a **stop-loss** 2 ATR below entry, which **trails upward** as price rises.
- **Sells** when the stop is hit or the trend reverses (EMA cross down).
- Position size = 1% of account risk ÷ stop distance, capped at 50% of equity.
- If the account drops **5% in one day**, everything is sold and trading halts
  until tomorrow.
- Expect a **few trades per month**. Reference result (2024-07 → 2026-07,
  $1,000 start, BTC+ETH): strategy −1% vs buy-and-hold −17%, with a max
  drawdown of −11.5% vs −59% for holding; over 3 years: +33.6% with −13.5%
  max drawdown. Honest caveat: in a strong bull market it will capture *less*
  than simply holding — smaller drawdowns are what you're buying.

All of these numbers are adjustable in **Settings**.

## Supercharged features

- **Backtest tab** — replays your exact strategy settings over years of real
  historical prices in seconds, side by side with a buy-and-hold benchmark.
  Use it to test changes *before* trading them. Watch the consistency check:
  if all the profit came from one half of the period, distrust the result.
- **EMA200 regime filter** (Settings) — skips buy signals in downtrending /
  choppy markets, the known weakness of trend strategies.
- **Maker fees** (Settings) — entries and calm exits use post-only limit
  orders in live mode (roughly half the fee); urgent stop-sells always use
  market orders because protection beats fee savings.
- **Exchange-side stop-losses** (live mode) — every position also gets a
  stop-limit order parked on Coinbase itself, so you're protected even if
  this PC is off or crashed.
- **Phone notifications** — set an ntfy.sh topic (install the free ntfy app,
  subscribe to your topic name) or a Telegram bot in Settings; the bot pings
  you on every trade, halt, or live-mode error.
- **Benchmark tile** — the dashboard shows your bot's return next to "what if
  you had just held BTC" over the same period. If the bot loses to holding
  for months, that's your answer — and knowing beats hoping.
- **Start with Windows** (Settings) — optional; the bot can't trade while the
  app is closed, so enable this if you want it always on.

## Going live (only after paper trading satisfies you)

1. Create an API key at <https://portal.cdp.coinbase.com> → API keys.
   Give it **View + Trade permission only — never Transfer/Withdraw**, so even
   a stolen key cannot drain your account.
2. Paste the key name and private key in the **API Keys** tab → Save → Test
   connection. Keys are encrypted with Windows DPAPI (tied to your Windows login).
3. In **Settings**, set the **Fee estimate** to your actual Coinbase taker fee
   (check Coinbase → fees; small accounts are typically ~0.75–1.2%).
4. Switch **Trading mode** to LIVE, save, and press Start.
5. Start small. Watch the History tab. You can pause or emergency-sell anytime.

## Files

- `run_trader.pyw` — launcher (no console window)
- `crypto_trader/` — application code (engine, GUI, storage, market data)
- `trader.db` — local database: settings, trade history, equity history, encrypted keys
- `error_log.txt` — written only if the app crashes at startup

## Requirements

- Python 3.10+ (installed)
- `ccxt` (installed) — only used for live trading; paper mode uses Coinbase's
  public market data with no keys at all.
