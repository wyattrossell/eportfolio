"""Headless entry point (Raspberry Pi / server): trading engine + web dashboard.

Run directly (python3 run_server.py) or via the systemd service that
deploy/install_pi.sh sets up. The dashboard is at http://<this-machine>:8080
(port configurable in Settings). If the bot was running when the process
stopped (crash, reboot, power cut), it resumes trading automatically.
"""

import pathlib
import queue
import sys

sys.path.insert(0, str(pathlib.Path(__file__).parent))

from crypto_trader.engine import Engine
from crypto_trader.store import Store
from crypto_trader.webapp import serve


def main():
    store = Store()
    events = queue.Queue()
    engine = Engine(store, events)
    engine.start()
    if store.get("engine_running") == "1":
        engine.commands.put(("start",))
        store.log("info", "Auto-resumed trading after restart")
    try:
        serve(store, engine)  # blocks forever
    except KeyboardInterrupt:
        engine.shutdown()


if __name__ == "__main__":
    main()
